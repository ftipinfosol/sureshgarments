			<div class="sidebar sidebar-main sidebar-fixed">
				<div class="sidebar-content">

					<!-- User menu -->
					<div class="sidebar-user-material">
						<div class="category-content">
							<div class="sidebar-user-material-content" style="min-height: 54px;">
							</div>
														
							<div class="sidebar-user-material-menu">
								<a href="#user-nav" target="_self" data-toggle="collapse"><span>Account : <?php echo e(Auth::user()->name); ?></span> <i class="caret"></i></a>
							</div>
						</div>
						
						<div class="navigation-wrapper collapse" id="user-nav">
							<ul class="navigation">
								<li><a href="#/myprofile"><i class="icon-user-plus"></i> <span>My profile</span></a></li>
								<li class="divider"></li>
								<li><a href="/logout"><i class="icon-switch2"></i> <span>Logout</span></a></li>
							</ul>
						</div>
					</div>
					<!-- /user menu -->


					<!-- Main navigation -->
					<div class="sidebar-category sidebar-category-visible">
						<div class="category-content no-padding">
							<ul class="navigation navigation-main navigation-accordion">

								<!-- Main -->
								<li class="navigation-header"><span>Home</span> <i class="icon-menu" title="Main pages"></i></li>
								<li><a href="#/dashboard"><i class="icon-home4"></i> <span>Dashboard</span></a></li>
								<li class="navigation-header"><span>Purchase</span> <i class="icon-menu" title="Main pages"></i></li>
								<li ng-class="{'active':title=='Purchase Order'}"><a href="#/purchase"><i class="icon icon-calculator"></i> <span>Purchase Order</span></a></li>
								<?php if(Auth::user()->Type=='Admin'): ?>
								<li ng-class="{'active':title=='Vouchers'}"><a href="#/vouchers"><i class="icon-coins"></i> <span>Vouchers</span></a></li>
								<?php endif; ?>
								<li class="navigation-header"><span>Sales</span> <i class="icon-menu" title="Main pages"></i></li>
								<li ng-class="{'active':title=='Packing Slip'}"><a href="#/packing-slip"><i class="icon icon-package"></i> <span>Packing Slip</span></a></li>
								<li ng-class="{'active':title=='Delivery Challan'}"><a href="#/dc"><i class="icon icon-truck"></i> <span>Delivery Challan</span></a></li>
								<li ng-class="{'active':title=='Invoices'}"><a href="#/invoice"><i class="icon icon-calculator"></i> <span>Invoice</span></a></li>
								<?php if(Auth::user()->Type=='Admin'): ?>
								<li ng-class="{'active':title=='Payments'}"><a href="#/payments"><i class="icon-coins"></i> <span>Payments</span></a></li>
								<li ng-class="{'active':title=='Reports'}"><a href="#/reports"><i class="glyphicon glyphicon-tasks"></i> <span>Reports</span></a></li>
								<li ng-class="{'active':title=='Transaction'}"><a href="#/transaction"><i class="glyphicon glyphicon-tasks"></i> <span>Transaction</span></a></li>
								<li ng-class="{'active':title=='Auditor Report'}"><a href="#/auditor-report"><i class="glyphicon glyphicon-tasks"></i> <span>Auditor Report</span></a></li>
								<?php endif; ?>
 
								<li class="navigation-header"><span>Master</span> <i class="icon-menu" title="Main pages"></i></li>
								<li ng-class="{'active':title=='Supplier'}"><a href="#/supplier"><i class="icon-coins"></i> <span>Supplier</span></a></li>
								<li ng-class="{'active':title=='Customers'}"><a href="#/customers"><i class="icon-users"></i> <span>Customers</span></a></li>
								<?php if(Auth::user()->Type=='Admin'): ?>
								<li ng-class="{'active':title=='Settings'}"><a href="#/settings"><i class="icon icon-gear"></i> <span>Settings</span></a></li>
								<li ng-class="{'active':title=='Users'}"><a href="#/users"><i class="icon icon-gear"></i> <span>Users</span></a></li>
								<?php endif; ?>
								<!-- /page kits -->

							</ul>
						</div>
					</div>
					<!-- /main navigation -->

				</div>
			</div>
			<!-- /main sidebar -->