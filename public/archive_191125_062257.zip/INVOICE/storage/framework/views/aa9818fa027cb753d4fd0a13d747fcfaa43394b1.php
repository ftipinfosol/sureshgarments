<!DOCTYPE html>
<html lang="en" ng-app="naresh" ng-cloak>

<!-- Mirrored from demo.interface.club/limitless/layout_1/LTR/material/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 11 Mar 2017 08:22:33 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title ng-bind="'Fashion - ' + $root.title">Fashion Elastics</title>

    <!-- Global stylesheets -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
    <link href="assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
    <link href="assets/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="assets/css/core.css" rel="stylesheet" type="text/css">
    <link href="assets/css/components.css" rel="stylesheet" type="text/css">
    <link href="assets/css/colors.css" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="kendo/kendo.common-material.min.css" />
    <link rel="stylesheet" href="kendo/kendo.material.min.css" />
    <link rel="stylesheet" href="kendo/kendo.material.mobile.min.css" />
    <!-- /global stylesheets -->
    <link href="assets/css/style.css" rel="stylesheet" type="text/css">
    
    <!-- Core JS files -->
    <script type="text/javascript" src="assets/js/core/libraries/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/core/libraries/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/plugins/ui/nicescroll.min.js"></script>
    <script type="text/javascript" src="assets/js/plugins/ui/layout_fixed_custom.js"></script>
    <!-- <script type="text/javascript" src="assets/js/plugins/loaders/pace.min.js"></script> -->
    
    <!-- <script type="text/javascript" src="assets/js/plugins/loaders/blockui.min.js"></script> -->
    <!-- <script type="text/javascript" src="assets/js/plugins/notifications/noty.min.js"></script> -->
    <script type="text/javascript" src="assets/js/core/app.js"></script>

</head>

<body layout="column" class="navbar-top  pace-done">
                <md-content>

    <!-- Main navbar -->
    <div class="navbar navbar-inverse bg-indigo navbar-fixed-top">
      <!--   <div class="navbar-header">

            <ul class="nav navbar-nav visible-xs-block">
                <li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5"></i></a></li>
                <li><a class="sidebar-mobile-main-toggle"><i class="icon-paragraph-justify3"></i></a></li>
            </ul>
        </div> -->
            <a class="navbar-brand" href=""  style="position:absolute;width: 237px;margin-top: -20px;left: 50%;margin-left: -120px;"><h3>Fashion Elastic</h3></a>
        
        <div class="navbar-collapse collapse" id="navbar-mobile">
            <ul class="nav navbar-nav">
                <li><a class="sidebar-control sidebar-main-toggle hidden-xs"><i class="icon-paragraph-justify3"></i></a></li>
            </ul>
        </div>
    </div>
    <!-- /main navbar -->


    <!-- Page container -->
    <div class="page-container">

        <!-- Page content -->
        <div class="page-content">

            <!-- Main sidebar -->
<?php echo $__env->make('layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;


            <!-- Main content -->
            <div class="content-wrapper slideInUp">

                <!-- Page header -->
                <div class="page-header page-header-default">
                    <div class="page-header-content">
                        <div class="page-title">
                            <h4><i class="icon-arrow-left52 position-left" style="font-size: 25px;" back></i> Home - <span class="text-semibold" ng-bind="$root.title"></span></h4>
                        

                        </div>

                        <div class="heading-elements">
                            <div class="heading-btn-group">
                                <a href="" class="btn btn-link btn-float text-size-small has-text">
                                    <md-progress-circular md-mode="indeterminate" ng-show="isLoading"></md-progress-circular>
                                </a>
                                <a href="#/new-packing-slip" class="btn btn-link btn-float text-size-small has-text"><i class="icon-package text-primary"></i> <span>Packing</span></a>
                                <a href="#/new-dc" class="btn btn-link btn-float text-size-small has-text"><i class="icon-truck text-primary"></i> <span>DC</span></a>
                                <a href="#/create-invoice" class="btn btn-link btn-float text-size-small has-text"><i class="icon-calculator text-primary"></i> <span>Invoice</span></a>
                                <a href="#/new-po" class="btn btn-link btn-float text-size-small has-text"><i class="icon-calculator text-primary"></i> <span>Purchase</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /page header -->


                <!-- Content area -->
                <div class="content">

                <div ng-view class="slideInUp ng-animate"></div>


                    <!-- Footer -->
                    <div class="footer text-muted">
                        &copy; 2017.
                    </div>
                    <!-- /footer -->
                </div>





                <!-- /content area -->

            </div>
            <!-- /main content -->

        </div>
        <!-- /page content -->

    </div>
    <!-- /page container -->
</md-content>
<link rel="stylesheet" href="material/angular-material.min.css">

<script src="material/angular.min.js"></script>

<script src="kendo/kendo.all.min.js"></script>

<script src="material/moment.min.js"></script>
<script src="material/angular-moment.min.js"></script>
<script src="material/angular-animate.min.js"></script>
<script src="material/angular-aria.min.js"></script>
<script src="material/angular-messages.min.js"></script>
<script src="material/angular-material.min.js"></script>
<script type="text/javascript" src="angular/img-crop.js"></script>
<script type='text/javascript' src="angular/angular-image-compress.js"></script>

<script type='text/javascript' src="angular/ng-table.min.js"></script>
<script type='text/javascript' src="angular/angular-route.min.js"></script> 
<script type='text/javascript' src="angular/service/app.js"></script> 
<script type='text/javascript' src="angular/service/admin.js"></script> 
<script type='text/javascript' src="angular/service/po.js"></script> 
<script type='text/javascript' src="angular/service/purchase.js"></script>
<?php if(Auth::user()->Type=='Admin'): ?> 
<script type='text/javascript' src="angular/service/users.js"></script> 
<?php endif; ?>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
</body>

</html>
