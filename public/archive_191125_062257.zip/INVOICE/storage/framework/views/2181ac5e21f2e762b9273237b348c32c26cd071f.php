<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.interface.club/limitless/layout_1/LTR/material/login_simple.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 11 Mar 2017 08:49:34 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Vivega Printers</title>

	<!-- Global stylesheets -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
	<link href="assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
	<link href="assets/css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="assets/css/core.css" rel="stylesheet" type="text/css">
	<link href="assets/css/components.css" rel="stylesheet" type="text/css">
	<link href="assets/css/colors.css" rel="stylesheet" type="text/css">
	<!-- /global stylesheets -->

	<!-- Core JS files -->
	<script type="text/javascript" src="assets/js/plugins/loaders/pace.min.js"></script>
	<script type="text/javascript" src="assets/js/core/libraries/jquery.min.js"></script>
	<script type="text/javascript" src="assets/js/core/libraries/bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/js/plugins/loaders/blockui.min.js"></script>
	<!-- /core JS files -->


	<!-- Theme JS files -->
	 <script type='text/javascript' src="angular/angular.min.js"></script>
	<script type='text/javascript' src="angular/angular-route.min.js"></script> 
	<script type="text/javascript" src="assets/js/core/app.js"></script>
	<script type="text/javascript" src="assets/js/plugins/ui/ripple.min.js"></script>
	<!-- /theme JS files -->

</head>

<body ng-app="naresh" class="login-container">

	<!-- Main navbar -->
	<div class="navbar navbar-inverse bg-indigo">
		<div class="navbar-header">
			<a class="navbar-brand" href="#"></a>

			<ul class="nav navbar-nav pull-right visible-xs-block">
				<li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5"></i></a></li>
			</ul>
		</div>

	</div>
	<!-- /main navbar -->


	<!-- Page container -->
	<div class="page-container">

		<!-- Page content -->
		<div class="page-content">

			<!-- Main content -->
			<div class="content-wrapper">

				<!-- Content area -->
				<div class="content">
					<ng-view></ng-view>
				</div>
				<!-- /content area -->
			</div>
			<!-- /main content -->
		</div>
		<!-- /page content -->

	</div>
	<!-- /page container -->
<script type="text/javascript">
var app =  angular.module('naresh',['ngRoute'])
.config(['$routeProvider',function($routeProvider) {        
    $routeProvider.when('/', {
        controller: 'ReCtr',
        templateUrl: 'register.html'
    })
    .otherwise({ redirectTo: '/' });
}])
.controller('ReCtr', function($http,$scope,$route,$window){
$scope.register = function()
{	
	$http({ url: 'login', method: 'POST',data:$scope.form}).success(function(data){
		$window.location.href = '/';
    }).error(function(data,status){
     	$scope.formError=data;
	       if(status==500)
	       {
	        $window.location.href = '/';        
	       }
    });
}
})
 </script>

<script type="text/ng-template" id="register.html">
		<form role="form" method="post" ng-submit="register()" name="login">
		<?php echo csrf_field(); ?>

			<div class="panel panel-body login-form">
				<div class="text-center">
					<div class="icon-object border-slate-300 text-slate-300"><i class="icon-reading"></i></div>
					<h5 class="content-group">Login to your account <small class="display-block">Enter your credentials below</small></h5>
				</div>

				<div class="form-group has-feedback has-feedback-left">
					<input type="text" class="form-control" placeholder="Username" ng-model="form.email" name="email" >
					<div class="form-control-feedback">
						<i class="icon-user text-muted"></i>
					</div>
					<label class="validation-error-label" ng-if="formError.email" ng-bind="formError.email" name="email" required></label>
				</div>

				<div class="form-group has-feedback has-feedback-left">
					<input type="password" class="form-control" placeholder="Password" ng-model="form.password" name="password" required>
					<div class="form-control-feedback">
						<i class="icon-lock2 text-muted"></i>
					</div>
					<label class="validation-error-label" ng-if="formError.password" ng-bind="formError.password"></label>
				</div>

				<div class="form-group login-options">
					<div class="row">
						<div class="col-sm-6">
							<label class="checkbox-inline">
								<div class="checker"><span class="checked"><input type="checkbox" class="styled" checked="checked" ng-model="form.remember"></span></div>
								Remember
							</label>
						</div>

						<div class="col-sm-6 text-right">
							<a href="#">Forgot password?</a>
						</div>
					</div>
				</div>

				<div class="form-group">
					<button type="submit" class="btn bg-pink-400 btn-block">Sign in <i class="icon-circle-right2 position-right"></i></button>
				</div>

			</div>
		</form>
</script>

</body>

</html>
