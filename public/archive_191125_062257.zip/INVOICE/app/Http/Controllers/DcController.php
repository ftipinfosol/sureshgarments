<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\CUSTOMER,Auth,App\DC,App\DCDE,DB;
use Carbon\Carbon;

class DcController extends Controller
{
	public function index(Request $request)
	{
		$data=DC::leftJoin('customers', 'customers.CID', '=', 'dc.CID')
		->selectRaw('dc.DCID,dc.DcNo,dc.CID,CName,dc.Qty,dc.Meters,Mobile1,Date,VNo')->where('dc.id',Auth::id());

		$filters=$request->filter['filters'][0];

		if(isset($filters['DcNo'])&&$filters['DcNo']!='')
		{
			$data->where('DcNo','LIKE','%'.$filters['DcNo'].'%');
		}
		if(isset($filters['CID'])&&$filters['CID']!='')
		{
			$data->where('dc.CID',$filters['CID']);
		}

		if(!isset($filters['Status'])||$filters['Status']!='Closed')
		{
			$data->whereNotIn('dc.DCID', 
				function($query) 
				{
					 $query->select('DCID')->from('details')->whereIn('IID',
					 	function($query2) 
					 	{ 
					 		$query2->select('IID')->from('invoice')->where('Status','!=','Cancelled');
					 	}); 
				});
		}
		else
		{
			$data->whereIn('dc.DCID', 
				function($query) 
				{
					 $query->select('DCID')->from('details')->whereIn('IID',
					 	function($query2) 
					 	{ 
					 		$query2->select('IID')->from('invoice')->where('Status','!=','Cancelled');
					 	}); 
				});
		}

		if(isset($filters['FromDate'])&&$filters['FromDate']!='NaN'&&isset($filters['ToDate'])&&$filters['ToDate']!='NaN')
        {
        	$data->whereBetween('Date',[$filters['FromDate'],$filters['ToDate']]);
        }
        $total = clone($data);
        $total=$total->count();
        $data->take($request->take)->skip($request->skip);
        if($request->sort)
        {
        	$data->orderBy('Date','DESC')->orderBy($request->sort[0]['field'],$request->sort[0]['dir']);

        }
        $data=$data->get();
		return response (['data'=>$data,'total'=>$total]);
	}

	public function getdc($id)
	{

		$data=DC::leftJoin('customers', 'customers.CID', '=', 'dc.CID')
		->whereNotIn('DCID', 
				function($query) 
				{
					 $query->select('DcNo')->from('details')->whereNotIn('IID',
					 	function($query2) 
					 	{ 
					 		$query2->select('IID')->from('invoice')->where('Status','Cancelled')->orWhere('Status','Regen');
					 	}); 
				})
		->select('DCID','DcNo','dc.CID','CName','Mobile1','Date','Meters','Qty','Des')
		->where('dc.CID',$id)->get();
		return response($data);

	}

	public function store(Request $request)
	{
		$input=$request->invoice;

		$date = Carbon::createFromTimestamp($input['Date']);
		$d_check = clone($date);
		$from = clone($date);
		$to = clone($date);

		if($d_check->format('m')<=3)
		{
			$from = '01-04-'.$from->addYear(-1)->format('Y');
			$to = '01-04-'.$to->format('Y');
		}
		else{
			$from = '01-04-'.$from->format('Y');
			$to = '01-04-'.$to->addYear(1)->format('Y');
		}
			$inv=DC::whereBetween(DB::raw("DATE(from_unixtime(Date))"),[Carbon::parse($from), Carbon::parse($to)])->where('id',Auth::id())->orderBy('DcNo','DESC')->first();
			if(isset($inv))
			{ $input['DcNo']=$inv->DcNo+1; }
			else
			{ $input['DcNo']=1; }
		
		$input['Status']='Open';		
		$data=DC::create($input);
		$details=$request->details;
		foreach ($details as $detail) {
			$detail['DcNo']=$data->DcNo;
			$detail['DCID']=$data->DCID;
			DCDE::create($detail);
		}
		return response($data);
	}


	public function edit($id)
	{
		$uid=Auth::user();
		$data=DC::leftJoin('customers', 'customers.CID', '=', 'dc.CID')
		->with('details')->find($id);
		return response($data);
	}

	public function update(Request $request,$id)
	{
		$input=$request->invoice;
		$data=DC::find($id);
		$data->update($input);

		DCDE::where('DCID',$id)->delete();
		$details=$request->details;
		foreach ($details as $detail) {
			$detail['DcNo']=$data->DcNo;
			$detail['DCID']=$data->DCID;
			DCDE::create($detail);
		}

		return response($data);
	}

	public function destroy($id)
	{
		$data=DC::find($id);
		$data->delete();
	}

	public function details(Request $request)
	{
		$data=DC::leftJoin('dcdetails','dcdetails.DCID','=','dc.DCID')
		->whereIn('dc.DCID',explode(',', $request->ids))
		->where('GST',$request->GST)
		->groupBy('dc.DCID')
		->select('*','dc.Meters','dc.Qty')
		->get();
		return response ($data);

		// $data=DCDE::whereIn('DCID',explode(',', $request->ids))
		// ->where('GST',$request->GST)
		// ->whereNotIn('DDID',function($query) use ($request)
		// 			 	{ 
		// 			 		$query->select('DDID')->from('details')->leftJoin('invoice', 'invoice.IID', '=', 'details.IID')->whereIn('DCID',explode(',', $request->ids))->where('Status','Payable');
		// 			 	})
		// ->where('Status','!=','C')->get();
		// return response ($data);
	}

}