<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\CUSTOMER,Auth,App\PURCHASE_ORDER,App\BPAYMENT,App\PURCHASE_ORDER_DETAILS,DB,App\PAYMENT,App\SETTINGS,App\DC,Mail;
use Carbon\Carbon;

class PurchaseOrderController extends Controller
{
	public function index(Request $request)
	{
		$data=PURCHASE_ORDER::leftJoin('supplier', 'supplier.SID', '=', 'purchase_order.SID')
		->where('purchase_order.id',Auth::id())
		->select('PODRID','PodrNo','Date','Delivery_Date','purchase_order.SID','Total','CName','Mobile1','Qty');

		$filters=$request->filter['filters'][0];
		
		if(isset($filters['Type'])&&$filters['Type']!='')
		{
			$data->where('Status','!=','Regen')->where('Status','!=','Cancelled');
		}

		if(isset($filters['PodrNo'])&&$filters['PodrNo']!='')
		{
			$data->where('PodrNo','LIKE','%'.$filters['PodrNo'].'%');
		}
		if(isset($filters['CName'])&&$filters['CName']!='')
		{
			$data->where('CName','LIKE','%'.$filters['CName'].'%');
		}
		if(isset($filters['Status'])&&$filters['Status']!='')
		{
			if($filters['Status']=='Payable')
			{
				$data->where(DB::raw('DATEDIFF(CURDATE(),DATE(from_unixtime(Due)))'),'<',1);
			}
			if($filters['Status']=='Overdue')
			{
				$data->where(DB::raw('DATEDIFF(CURDATE(),DATE(from_unixtime(Due)))'),'>',0)->where('Status','!=','Closed');
			}
			else
			{
				$data->where('Status','=',$filters['Status']);
			}
			
		}
		if(isset($filters['FromDate'])&&$filters['FromDate']!='NaN'&&isset($filters['ToDate'])&&$filters['ToDate']!='NaN')
        {
        	$data->whereBetween('Date',[$filters['FromDate'],$filters['ToDate']]);
        }

        $total=count($data->get());
        $data->take($request->take)->skip($request->skip);
        if($request->sort)
        {
        	$data->orderBy('Date','DESC')->orderBy($request->sort[0]['field'],$request->sort[0]['dir']);	
        }
        $data=$data->get();
		return response (['data'=>$data,'total'=>$total]);
	}

	public function store(Request $request)
	{
		$user=Auth::user();
		$input=$request->invoice;
		$det=$request->details;

		$input=$request->invoice;
		$input['Status']='Payable';
		if(!isset($input['RID']))
		{
			$date = Carbon::createFromTimestamp($input['Date']);
			$d_check = clone($date);
			$from = clone($date);
			$to = clone($date);

			if($d_check->format('m')<=3)
			{
				$from = '01-04-'.$from->addYear(-1)->format('Y');
				$to = '01-04-'.$to->format('Y');
			}
			else{
				$from = '01-04-'.$from->format('Y');
				$to = '01-04-'.$to->addYear(1)->format('Y');
			}

			$inv=PURCHASE_ORDER::whereBetween(DB::raw("DATE(from_unixtime(Date))"),[Carbon::parse($from), Carbon::parse($to)])->where('id',Auth::id())->orderBy('PodrNo','DESC')->first();
			if(isset($inv))
			{ $input['PodrNo']=$inv->PodrNo+1; }
			else
			{ $input['PodrNo']=1001; }

		$today=Carbon::now();
		$td_yr=$today->format('y');

		if(isset($inv->created_at)){
			$yr=$inv->created_at->format('y');
		}else{
			$yr=$today->format('y');
		}
		


		
		if($td_yr==$yr){
			$input['prefix']='FE/'.$yr;
		}else{
			$input['prefix']='FE/'.$td_yr;
		}

		}
		else
		{
			$inv2=PURCHASE_ORDER::find($input['RID']);
			if($inv2->Status=='Cancelled')
			{
				$inv2->update(['Status'=>'Regen']);
				$input['PodrNo']=$inv2->PodrNo;
			}
			else
			{
				return response('Cant Generate ',422);
			}
		}
		

		$data=PURCHASE_ORDER::create($input);

		$details=$request->details;
		foreach ($details as $detail) {
			$detail['PODRID']=$data->PODRID;
			PURCHASE_ORDER_DETAILS::create($detail);
		}
		return response($data);
	}

	public function paid($id)
	{
		$data=PURCHASE_ORDER::find($id);
		$input['Status']="Closed";
		$data->update($input);

	}

	public function status(Request $request)
	{
		$pay=PAYMENT::where('PODRID',$request->PODRID)->first();
		if(isset($pay))
		{
			return response('There is Active Payments. Cant '.$request->Status,422);
		}
		$input=$request->all();
		$data=PURCHASE_ORDER::find($request->PODRID);
		if($data->Status!='Closed'&&$data->Status!='Regen')
		{
			if($data->Status=="Cancelled")
			{
				$data->update(['Status'=>'Payable']);
			}
			else
			{
				$data->update(['Status'=>'Cancelled']);
			}
		}
		else
		{
			return response('Cant Cancel ',422);
		}
		return response($data);
	}

	public function edit($id)
	{
		$uid=Auth::user();
		$data=PURCHASE_ORDER::leftJoin('supplier', 'supplier.SID', '=', 'purchase_order.SID')
		->with('details')->find($id);
		return response($data);
	}

	public function update(Request $request,$id)
	{
		
		$data=PURCHASE_ORDER::find($id);
	
		$input=$request->invoice;
		$data=PURCHASE_ORDER::find($id);
		$data->update($input);

		PURCHASE_ORDER_DETAILS::where('PODRID',$id)->delete();
		$details=$request->details;
		foreach ($details as $detail) {
			$detail['PODRID']=$data->PODRID;
			PURCHASE_ORDER_DETAILS::create($detail);
		}

		return response($data);
	}

	public function binvpay(Request $request)
	{

		$data1=PURCHASE_ORDER::leftjoin('supplier','supplier.SID','=','purchase_order.SID')
		->select('purchase_order.SID','CName','Name','purchase_order.id','Mobile1',DB::raw('SUM(Total) As Inv'))
		->whereNotIn('Status',['Cancelled','Regen'])
		->where('purchase_order.id',Auth::id())
		->groupBy('purchase_order.SID')
		->orderBy('purchase_order.SID','asc')
		->get();

		$data2=BPAYMENT::leftjoin('supplier','supplier.SID','=','bpayment.SID')
		->select('bpayment.SID','CName','bpayment.id','Mobile1',DB::raw('SUM(Amount) As Pay'))
		->where('bpayment.id',Auth::id())
		->groupBy('bpayment.SID')
		->orderBy('bpayment.SID','asc')
		->get();

		return response (['data1'=>$data1,'data2'=>$data2]);
	}

	public function searchbinvpay(Request $request)
	{

		$data1=PURCHASE_ORDER::leftjoin('supplier','supplier.SID','=','purchase_order.SID')
		->select('purchase_order.SID','CName','Name','purchase_order.id','Mobile1',DB::raw('SUM(Total) As Inv'))
		->where('CName',$request->CName)
		->whereNotIn('Status',['Cancelled','Regen'])
		->where('purchase_order.id',Auth::id())
		->groupBy('purchase_order.SID')
		->orderBy('purchase_order.SID','asc')
		->get();

		$data2=BPAYMENT::leftjoin('supplier','supplier.SID','=','bpayment.SID')
		->select('bpayment.SID','CName','bpayment.id','Mobile1',DB::raw('SUM(Amount) As Pay'))
		->where('CName',$request->CName)
		->where('bpayment.id',Auth::id())
		->groupBy('bpayment.SID')
		->orderBy('bpayment.SID','asc')
		->get();

		return response (['data1'=>$data1,'data2'=>$data2]);
	}

	public function destroy($id)
	{
		$data=PURCHASE_ORDER::find($id);
		$lead=PAYMENT::where('PODRID',$id)->first();
		if(isset($lead))
		{
			return response(['error'],422);
		}
		$data->delete();
	}

	public function auditor(Request $request)
	{
		$total=PURCHASE_ORDER::selectRaw('SUM(Amount) As Amount,SUM(CGST) As CGST,SUM(SGST) As SGST,SUM(IGST) As IGST,SUM(Total) As Total')
		->whereBetween('Date',[$request->FromDate,$request->ToDate])
		->whereNotIn('Status',['Cancelled','Regen'])
		->where('purchase_order.id',Auth::id())
		->first();

		$report=PURCHASE_ORDER::leftJoin('supplier', 'supplier.SID', '=', 'purchase_order.SID')->select('CName','TIN','Date','PodrNo','Amount','CGST','SGST','IGST','Total')
		->whereBetween('Date',[$request->FromDate,$request->ToDate])
		->whereNotIn('Status',['Cancelled','Regen'])
		->where('purchase_order.id',Auth::id())
		->orderBy('PodrNo','asc')
		->get();

		
		$data['Report']=$report;
		$data['From']=$request->FromDate;
		$data['To']=$request->ToDate;
		$data['Amount']=$total->Amount;
		$data['CGST']=$total->CGST;
		$data['SGST']=$total->SGST;
		$data['IGST']=$total->IGST;
		$data['Total']=$total->Total;
		return response($data);
	}

	public function sendinvoice(Request $request)
	{
		$user=Auth::user();

		$data = base64_decode(preg_replace('#^data:application/\w+;base64,#i', '', $request->Pdf));

		file_put_contents('purchase_order.pdf', $data);

		$from=$user->email;
		$to=$request->Email;
		$subject=$request->Subject;

		config(['mail.driver' => $user->Driver,
				'mail.host' => $user->Host,
				'mail.port' => $user->Port,
				'mail.encryption' => $user->Encryption,
				'mail.username' => $user->email,
				'mail.password' => $user->MPassword]);


		Mail::queue('layout.template',['data'=>$request->Body],function($message) use ($from,$to,$subject)
         {
            $message->from($from)->to($to)->subject($subject)
            ->attach('purchase_order.pdf');
		            
        });

        unlink('purchase_order.pdf');

	}


}