<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\SUPPLIER,Auth,App\PURCHASE,App\PDETAILS,DB;
use App\ITEM;

class PurchaseController extends Controller
{
	public function index(Request $request)
	{
			
		$data=PURCHASE::leftJoin('supplier', 'supplier.SID', '=', 'po.SID')
		->select('POID','PoNo','Date','po.SID','Total','Balance','Status','CName','Mobile1');

		$filter=$request->filter;
		if(isset($filter['Type'])&&$filter['Type']!='')
		{
			$data->where('Status','!=','Regen')->where('Status','!=','Cancelled');
		}

		if(isset($filter['PoNo'])&&$filter['PoNo']!='')
		{
			$data->where('PoNo','LIKE','%'.$filter['PoNo'].'%');
		}
		if(isset($filter['CName'])&&$filter['CName']!='')
		{
			$data->where('CName','LIKE','%'.$filter['CName'].'%');
		}

		if(isset($filter['FromDate'])&&$filter['FromDate']!='NaN'&&isset($filter['ToDate'])&&$filter['ToDate']!='NaN')
        {
        	$data->whereBetween('Date',[$filter['FromDate'],$filter['ToDate']]);
        }

        $total=count($data->get());
        $data = $data->take($request->take)->skip($request->skip)
        ->orderBy(key((array)($request->orderBy)),current((array)($request->orderBy)))
        ->get();
		return response (['data'=>$data,'total'=>$total]);
	}

	public function show($id)
	{
		$data=PURCHASE::find($id);

		if($data->Status=='Completed')
		{
			return;
		}
		$dedel = PDETAILS::where('POID',$id)->get();
		foreach ($dedel as $detail) {

			$qty=ITEM::find($detail['ITID']);
			if(isset($qty))
			{
				$qty->update(['AQty'=>$qty->AQty+$detail['Qty']]);				
			}			
		}
		$data->update(['Status'=>'Completed']);
		return response($data);
	}

	public function store(Request $request)
	{
		$user=Auth::user();
		$input=$request->purchase;
		$det=$request->details;

		// $input['Status']='Payable';
		// if(!isset($input['RID']))
		// {
		// 	$inv=PURCHASE::orderBy('PoNo','DESC')->first();
		// 	if(isset($inv))
		// 	{ $input['PoNo']=$inv->PoNo+1; }
		// 	else
		// 	{ $input['PoNo']=1; }
		// }
		// else
		// {
		// 	$inv2=PURCHASE::find($input['RID']);
		// 	if($inv2->Status=='Cancelled')
		// 	{
		// 		$inv2->update(['Status'=>'Regen']);
		// 		$input['PoNo']=$inv2->PoNo;
		// 	}
		// 	else
		// 	{
		// 		return response('Cant Generate ',422);
		// 	}
		// }
		// return response($input,422);

		$data=PURCHASE::create($input);

		$details=$request->details;
		foreach ($details as $detail) {
			$detail['POID']=$data->POID;

			// $qty=ITEM::find($detail['ITID']);
			// if(isset($qty))
			// {
			// 	$qty->update(['AQty'=>$qty->AQty+$detail['Qty']]);				
			// }
			PDETAILS::create($detail);
		}
		return response($data);
	}

	public function status(Request $request)
	{
		// $pay=PAYMENT::where('POID',$request->POID)->first();
		// if(isset($pay))
		// {
		// 	return response('There is Active Payments. Cant '.$request->Status,422);
		// }
		$input=$request->all();
		$data=PURCHASE::find($request->POID);
		if($data->Status!='Closed'&&$data->Status!='Regen')
		{
			if($data->Status=="Cancelled")
			{
				// $dedel = PDETAILS::where('POID',$request->POID)->get();
				// foreach ($dedel as $detail) {

				// 	$qty=ITEM::find($detail['ITID']);
				// 	if(isset($qty))
				// 	{
				// 		$qty->update(['AQty'=>$qty->AQty-$detail['Qty']]);				
				// 	}			
				// }

				$data->update(['Status'=>'Payable']);
			}
			else
			{
				$dedel = PDETAILS::where('POID',$request->POID)->get();
				// foreach ($dedel as $detail) {

				// 	$qty=ITEM::find($detail['ITID']);
				// 	if(isset($qty))
				// 	{
				// 		$qty->update(['AQty'=>$qty->AQty+$detail['Qty']]);				
				// 	}			
				// }

				$data->update(['Status'=>'Cancelled']);
			}
		}
		else
		{
			return response('Cant Cancel ',422);
		}
		return response($data);
	}

	public function edit($id)
	{
		$uid=Auth::user();
		$data=PURCHASE::leftJoin('supplier', 'supplier.SID', '=', 'po.SID')
		->with('details')->find($id);
		return response($data);
	}

	public function update(Request $request,$id)
	{
		$user=Auth::user();
		$input=$request->purchase;
		$data=PURCHASE::find($id);
		$data->update($input);

		// $dedel = PDETAILS::where('POID',$id)->get();
		// foreach ($dedel as $detail) {

		// 	$qty=ITEM::find($detail['ITID']);
		// 	if(isset($qty))
		// 	{
		// 		$qty->update(['AQty'=>$qty->AQty-$detail['Qty']]);				
		// 	}			
		// }

		PDETAILS::where('POID',$id)->delete();
		$details=$request->details;
		foreach ($details as $detail) {
			$detail['POID']=$data->POID;

			// $qty=ITEM::find($detail['ITID']);
			// if(isset($qty))
			// {
			// 	$qty->update(['AQty'=>$qty->AQty+$detail['Qty']]);				
			// }

			PDETAILS::create($detail);
		}

		return response($data);
	}

	public function destroy($id)
	{
		$data=PURCHASE::find($id);
		PDETAILS::where('POID',$id)->delete();
		$data->delete();
	}

	public function auditor(Request $request)
	{
		$total=PURCHASE::selectRaw('SUM(Amount) As Amount,SUM(CGST) As CGST,SUM(SGST) As SGST,SUM(IGST) As IGST,SUM(Total) As Total')
		->whereBetween('Date',[$request->FromDate,$request->ToDate])
		->first();

		$report=PURCHASE::leftJoin('supplier', 'supplier.SID', '=', 'po.SID')->select('Name','TIN','Date','PoNo','Amount','CGST','SGST','IGST','Total')
		->whereBetween('Date',[$request->FromDate,$request->ToDate])
		->get();

		
		$data['Report']=$report;
		$data['From']=$request->FromDate;
		$data['To']=$request->ToDate;
		$data['Amount']=$total->Amount;
		$data['CGST']=$total->CGST;
		$data['SGST']=$total->SGST;
		$data['IGST']=$total->IGST;
		$data['Total']=$total->Total;
		return response($data);
	}


}