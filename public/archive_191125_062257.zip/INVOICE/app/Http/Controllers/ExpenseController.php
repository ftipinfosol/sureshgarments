<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\EXPENSE,Auth,App\PURCHASE,DB,App\User,App\SUPPLIER;

class ExpenseController extends Controller
{
	public function index(Request $request)
	{

		$data=EXPENSE::leftJoin('supplier', 'supplier.SID', '=', 'expense.SID')->where('expense.id',Auth::id());

		$filter=$request->filter;

		if(isset($filter['Type'])&&$filter['Type']!='')
        {

            $data->where('Type',$filter['Type']);
        }
        else
        {
        	$data->where('Type','!=','Purchase');
        }

		if(isset($filter['Name'])&&$filter['Name']!='')
        {
            $data->where(function ($query) use ($filter){
			    $query->where('CName','LIKE','%'.$filter['Name'].'%')->orWhere('Mobile1','LIKE','%'.$filter['Name'].'%');
			});
        }

        if(isset($filter['FromDate'])&&$filter['FromDate']!='NaN'&&isset($filter['ToDate'])&&$filter['ToDate']!='NaN')
        {
        	$data->whereBetween('Date',[$filter['FromDate'],$filter['ToDate']]);
        }

        $amount = $data->selectRaw('SUM(Amount) As Amount')->first();

        $total=count($data->get());
        $data = $data->select('*')->take($request->take)->skip($request->skip)
        ->orderBy(key((array)($request->orderBy)),current((array)($request->orderBy)))
        ->get();
		return response (['data'=>$data,'total'=>$total,'amount'=>$amount]);

	}

	public function show($id)
	{		
		$data=EXPENSE::groupBy('GST')->get();
		return response($data);
	}

	public function store(Request $request)
	{
		$input=$request->all();

		$data=EXPENSE::create($input);
		$data=EXPENSE::leftJoin('supplier', 'supplier.SID', '=', 'expense.SID')->find($data->EXID);

		return response($data);
	}

	public function update(Request $request,$id)
	{
		$data=EXPENSE::find($id);
		$input=$request->all();

		$data->update($input);		
		$data=EXPENSE::leftJoin('supplier', 'supplier.SID', '=', 'expense.SID')->find($data->EXID);
		return response($data);
	}

	public function destroy($id)
	{
		$data=EXPENSE::find($id);
		$data->delete();
	}

	public function report(Request $request)
	{
		$beg1=PURCHASE::select(DB::raw('SUM(Total) As Inv'))->where('SID',$request->SID)->whereNotIn('Status',['Cancelled','Regen'])->where('Date','<',$request->FromDate)->first();
		$beg2=EXPENSE::select(DB::raw('SUM(Amount) As Pay'))->where('SID',$request->SID)->where('Date','<',$request->FromDate)->first();

		$beg3=PURCHASE::select(DB::raw('SUM(Total) As Inv'))
		->where('SID',$request->SID)
		->whereNotIn('Status',['Cancelled','Regen'])
		->whereBetween('Date',[$request->FromDate,$request->ToDate])
		->first();
		$beg4=EXPENSE::select(DB::raw('SUM(Amount) As Pay'))
		->where('SID',$request->SID)
		->whereBetween('Date',[$request->FromDate,$request->ToDate])
		->first();

		$report=DB::select("SELECT * FROM (
		(SELECT po.Total As Inv, '' AS Rec, po.SID, po.Date, po.PoNo As No, po.Status As Status FROM po)
		    UNION ALL
		    (SELECT '' AS Inv, expense.Amount As Rec, expense.SID, expense.Date, CONCAT(expense.ChequeNo,'-',expense.Detail) As No, '' As Status FROM expense)
		) results WHERE SID = ".$request->SID." AND Status NOT IN ('Cancelled','Regen') AND Date BETWEEN ".$request->FromDate." AND ".$request->ToDate);

		
		$data=SUPPLIER::select('SID','CName')->find($request->SID);
		$data['Report']=$report;
		$data['Beginning']=$beg1->Inv-$beg2->Pay;
		$data['From']=$request->FromDate;
		$data['To']=$request->ToDate;
		$data['InvTot']=$beg3->Inv;
		$data['RecTot']=$beg4->Pay;
		$data['Closing']=$data['Beginning']+$data['InvTot']-$data['RecTot'];

		// return response($beg3);
		return response($data);
	}

}