<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\CUSTOMER,Auth,App\INVOICE,App\BPAYMENT,App\DETAILS,DB,App\PURCHASE,App\VOUCHER;

class BulkPaymentController extends Controller
{
	public function index(Request $request)
	{
		$data=BPAYMENT::leftJoin('customers', 'customers.CID', '=', 'bpayment.CID')->select('*')->where('bpayment.id',Auth::id());

		$filter=$request->filter;
		if(isset($filter['Name'])&&$filter['Name']!='')
        {
            $data->where(function ($query) use ($filter){
			    $query->where('CName','LIKE','%'.$filter['Name'].'%')->orWhere('Mobile1','LIKE','%'.$filter['Name'].'%');
			});
        }

        if(isset($filter['FromDate'])&&$filter['FromDate']!='NaN'&&isset($filter['ToDate'])&&$filter['ToDate']!='NaN')
        {
        	$data->whereBetween('Date',[$filter['FromDate'],$filter['ToDate']]);
        }

        $total=count($data->get());
        $data = $data->take($request->take)->skip($request->skip)
        ->orderBy(key((array)($request->orderBy)),current((array)($request->orderBy)))
        ->get();
		return response (['data'=>$data,'total'=>$total]);

	}

	public function show($id)
	{
		// $data=INVOICE::leftJoin('customers', 'customers.CID', '=', 'invoice.CID')
		// ->select('IID','Date','invoice.CID','invoice.id','InvNo','Amount','Balance','Status','City','CName')->find($id);
		$data=BPAYMENT::leftJoin('customers', 'customers.CID', '=', 'bpayment.CID')->select('*')
		->where('bpayment.id',Auth::id())->where('bpayment.CID',$id)->get();
		return response($data);
	}

	public function indexx($id)
	{
		$data=BPAYMENT::leftJoin('customers', 'customers.CID', '=', 'bpayment.CID')->select('*')
		->where('bpayment.id',Auth::id())->where('bpayment.CID',$id)->orderBy('bpayment.created_at','DESC')->get();
		return response($data);
	}

	public function edit($id)
	{
		$form=BPAYMENT::find($id);

		$data=INVOICE::leftJoin('customers', 'customers.CID', '=', 'invoice.CID')
		->select('IID','Date','invoice.CID','invoice.id','InvNo','Amount','Balance','Status','City','CName')->find($form->IID);
		
		return response(['data'=>$data,'form'=>$form]);
	}

	public function store(Request $request)
	{
		$input=$request->all();

		$data=BPAYMENT::create($input);
		$data=BPAYMENT::leftJoin('customers', 'customers.CID', '=', 'bpayment.CID')->find($data->PID);
		$cust=CUSTOMER::find($request->CID);
		$advance=$request->Advance;
		$inp['Advance']=$advance;
		$cust->update($inp);
		return response($data);
	}

	public function update(Request $request,$id)
	{
		$data=BPAYMENT::find($id);
		$input=$request->all();

		$data->update($input);		
		$data=BPAYMENT::leftJoin('customers', 'customers.CID', '=', 'bpayment.CID')->find($data->PID);
		return response($data);
	}

	public function report(Request $request)
	{
		$id=Auth::id();
		$from = date('Y-m-d',$request->FromDate);
		$to = date('Y-m-d',$request->ToDate);

		$invoice=INVOICE::where('CID',$request->CID)
		->whereNotIn('Status',['Cancelled','Regen'])
		->where('invoice.id',Auth::id())
		->lists('IID','IID');
		
		$beg1=INVOICE::select(DB::raw('SUM(Total) As Inv'))
		->where('CID',$request->CID)
		->whereNotIn('Status',['Cancelled','Regen'])
		// ->where('Date','<',$from)
		->whereRaw("DATE(from_unixtime(Date)) < '$from'")
		->where('invoice.id',Auth::id())
		->first();

		$beg2=BPAYMENT::select(DB::raw('SUM(Amount) As Pay'))
		->where('CID',$request->CID)
		->whereRaw("DATE(from_unixtime(Date)) < '$from'")
		// ->where('Date','<',$from)
		->where('bpayment.id',Auth::id())
		->first();

		$beg3=INVOICE::select(DB::raw('SUM(Total) As Inv'))
		->where('CID',$request->CID)
		->whereNotIn('Status',['Cancelled','Regen'])
		// ->whereBetween('Date',[$from,$to])
		->whereRaw("DATE(from_unixtime(Date)) BETWEEN '$from' AND '$to'")
		->where('invoice.id',Auth::id())
		->first();

		$beg4=BPAYMENT::select(DB::raw('SUM(Amount) As Pay'))->where('CID',$request->CID)->whereRaw("DATE(from_unixtime(Date)) BETWEEN '$from' AND '$to'")->first();



		$open=INVOICE::select('Total')
		->where('InvNo','0')
		->where('CID',$request->CID)
		->whereNotIn('Status',['Cancelled','Regen'])
		->where('invoice.id',Auth::id())
		->first();





		$report=DB::select("SELECT * FROM (

			(SELECT invoice.Total As Inv, '' AS Rec,'' As Type, invoice.CID, invoice.Date, invoice.InvNo As No, invoice.Status As Status FROM invoice WHERE id = $id)

			UNION ALL

			(SELECT po.Total AS Inv, '' As Rec, '' As Type, po.CID, po.Date, po.PoNo As No, '' As Status FROM po WHERE id = $id)

			UNION ALL

			(SELECT '' AS Inv, bpayment.Amount As Rec, bpayment.Cheque As Type, bpayment.CID, bpayment.Date, bpayment.ChequeNo As No, '' As Status FROM bpayment WHERE id = $id)

		) results WHERE CID = '$request->CID' AND Status NOT IN ('Cancelled','Regen') AND DATE(from_unixtime(Date)) BETWEEN '$from' AND '$to' ORDER BY Date ASC");

		
		$data=CUSTOMER::select('CID','CName')->find($request->CID);
		$data['Report']=$report;
		$data['Beginning']=$beg1->Inv-$beg2->Pay;
		$data['From']=$request->FromDate;
		$data['To']=$request->ToDate;
		$data['InvTot']=$beg3->Inv;
		$data['RecTot']=$beg4->Pay;
		$data['Closing']=$data['Beginning']+$data['InvTot']-$data['RecTot'];
		$data['opening']=$open->Total;

		// return response($beg3);
		return response($data);
	}

	public function dash()
	{

		$id=Auth::id();
		$today=strtotime('12:00:00');
		$invoice=INVOICE::leftJoin('customers', 'customers.CID', '=', 'invoice.CID')
		->select('IID','InvNo','Date','invoice.CID','invoice.id','Total','Balance','Status','CName')
		->where('InvNo','!=',0)
		->where('invoice.id',$id)->orderBy('IID','DESC')->take(5)->get();
		$invamount=INVOICE::select(DB::raw('SUM(Total) As Amount,SUM(Balance) As Balance'))->where('id',$id)->first();

		$payment=BPAYMENT::leftJoin('customers', 'customers.CID', '=', 'payment.CID')
		->select('PID','payment.CID','CName','payment.Date','Cheque','Bank','payment.Amount')
		->where('payment.id',$id)->where('payment.Amount','!=','')->orderBy('PID','DESC')->take(5)->get();

		$stat=INVOICE::selectRaw("sum(case when Status = 'Payable' then 1 else 0 end) Payable, sum(case when Status = 'Payable' And DATEDIFF(CURDATE(),DATE(from_unixtime(Due)))>0 then 1 else 0 end) Overdue, count(*) Total")
		->where('id',$id)->first();

		$report=DB::select("SELECT SUM(Inv) As Invoice, SUM(Rec) As Payment, Date FROM (
		(SELECT SUM(invoice.Total) As Inv, '' AS Rec, Date  FROM invoice WHERE id = $id GROUP BY YEAR(from_unixtime(Date)), MONTH(from_unixtime(Date)))
		    UNION ALL
		    (SELECT '' AS Inv, SUM(payment.Amount) As Rec, Date FROM payment WHERE id = $id GROUP BY YEAR(from_unixtime(Date)), MONTH(from_unixtime(Date)))
		) results GROUP BY YEAR(from_unixtime(Date)), MONTH(from_unixtime(Date))");

		// return response (['request'=>$report]);
		return response (['invoice'=>$invoice,'invamount'=>$invamount,'payment'=>$payment,'stat'=>$stat,'report'=>$report]);

	}

	public function destroy($id)
	{
		$data=BPAYMENT::find($id);
		$data->delete();
	}
}
