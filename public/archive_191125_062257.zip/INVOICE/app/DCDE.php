<?php

namespace App;

use Illuminate\Database\Eloquent\Model,Auth;

class DCDE extends Model
{
		protected $table="dcdetails";
    	protected $primaryKey="DDID";
    	protected $fillable = [
            'id',
            'DCID',
            'DcNo',
            'ITID',
            'IName',
            'HSN',
            'Rate',
            'GST',
            'Qty',
            'Meters',
		];

		protected $hidden = [
        'created_at', 'updated_at'
        ];

        public function save(array $options = array())
        {
            if(!$this->id)
            {
                $this->id = Auth::user()->id;
            }
            parent::save($options);
        }
}