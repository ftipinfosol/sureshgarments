<?php

namespace App;

use Illuminate\Database\Eloquent\Model,Auth;

class PURCHASE_ORDER_DETAILS extends Model
{
		protected $table="purchase_order_details";
    	protected $primaryKey="PODRDID";
    	protected $fillable = [
            'id',
            'PODRID',
            'ITID',
            'HSN',
            'IName',
            'Unit',
            'Rate',
            'Qty',
            'GST',
            'RCGST',
            'CGST',
            'RSGST',
            'SGST',
            'RIGST',
            'IGST',
            'Amount',
            'Total',
		];

         public function save(array $options = array())
        {
            if(!$this->id)
            {
                $this->id = Auth::user()->id;
            }
            parent::save($options);
        }
}