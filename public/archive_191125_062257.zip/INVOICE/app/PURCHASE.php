<?php

namespace App;

use Illuminate\Database\Eloquent\Model,Auth;

class PURCHASE extends Model
{
		protected $table="po";
    	protected $primaryKey="POID";
    	protected $fillable = [
            'PoNo',
            'Date',
            'SID',
            'Qty',
            'Amount',
            'CGST',
            'SGST',
            'IGST',
            'Round',
            'Total',
            'Balance',
            'Status',
		];



        public function details()
        {
            return $this->hasMany('App\PDETAILS', 'POID','POID');
        }
}