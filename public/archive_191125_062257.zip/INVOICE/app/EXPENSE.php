<?php

namespace App;

use Illuminate\Database\Eloquent\Model,Auth;

class EXPENSE extends Model
{
		protected $table="expense";
    	protected $primaryKey="EXID";
    	protected $fillable = [
            'Type',
            'SID',
            'id',
            'Date',
            'Bank',
            'Cheque',
            'ChequeNo',
            'Amount',
            'Detail',
		];

		public function save(array $options = array())
        {
            if(!$this->id)
            {
                $this->id = Auth::user()->id;
            }
            parent::save($options);
        }
}