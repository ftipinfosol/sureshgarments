<?php

namespace App;

use Illuminate\Database\Eloquent\Model,Auth;

class BPAYMENT extends Model
{
		protected $table="bpayment";
    	protected $primaryKey="PID";
    	protected $fillable = [
            'CID',
            'id',
            'comid',
            'Date',
            'Bank',
            'Cheque',
            'ChequeNo',
            'Amount',
            'Status',
            'Detail',
		];

        protected $hidden = [
        'comid'
        ];

        public function save(array $options = array())
        {
            if(!$this->id)
            {
                $this->id = Auth::user()->id;
            }
            parent::save($options);
        }

        // public function newQuery($excludeDeleted = true) {
        //     return parent::newQuery($excludeDeleted)
        //         ->where('comid', Auth::user()->comid);
        // }
}