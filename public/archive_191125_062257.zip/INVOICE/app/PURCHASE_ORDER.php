<?php

namespace App;

use Illuminate\Database\Eloquent\Model,Auth;

class PURCHASE_ORDER extends Model
{
		protected $table="purchase_order";
    	protected $primaryKey="PODRID";
    	protected $fillable = [
            'id',
            'prefix',
            'PodrNo',
            'Date',
            'SID',
            'Qty',
            'Amount',
            'CGST',
            'SGST',
            'IGST',
            'Round',
            'Disc',
            'DiscAmount',
            'SubTotal',
            'Total',
            'Balance',
            'Status',
            'Delivery_At',
            'Delivery_Time',
            'Delivery_Date',
            'Payment_terms',
		];



        public function details()
        {
            return $this->hasMany('App\PURCHASE_ORDER_DETAILS', 'PODRID','PODRID');
        }
         public function save(array $options = array())
        {
            if(!$this->id)
            {
                $this->id = Auth::user()->id;
            }
            parent::save($options);
        }
}