<?php

namespace App;

use Illuminate\Database\Eloquent\Model,Auth;

class DC extends Model
{
		protected $table="dc";
    	protected $primaryKey="DCID";
        protected $fillable = [
            'id',
            'CID',
            'DcNo',
            'Date',
            'VNo',
            'EWay',
            'Des',
            'Qty',
            'Meters',
        ];

        protected $hidden = [
        'created_at', 'updated_at'
        ];

        public function details()
        {
            return $this->hasMany('App\DCDE', 'DCID','DCID');
        }

        public function save(array $options = array())
        {
            if(!$this->id)
            {
                $this->id = Auth::user()->id;
            }
            parent::save($options);
        }

}