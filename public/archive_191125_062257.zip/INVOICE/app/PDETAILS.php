<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PDETAILS extends Model
{
		protected $table="pdetails";
    	protected $primaryKey="PDID";
    	protected $fillable = [
            'POID',
            'ITID',
            'HSN',
            'IName',
            'Rate',
            'Qty',
            'GST',
            'RCGST',
            'CGST',
            'RSGST',
            'SGST',
            'RIGST',
            'IGST',
            'Amount',
            'Total',
		];
}