app.config(['$routeProvider',function($routeProvider) {        
    $routeProvider
    .when('/dc', {
        controller: 'DcCtr',
        templateUrl: '/app/purchase.dc.html',
        title: 'Delivery Challan'
    })
    .when('/new-dc', {
        controller: 'NewDcCtr',
        templateUrl: '/app/purchase.new-dc.html',
        title: 'Delivery Challan'
    })
    .when('/dc-invoice/:dc', {
        controller: 'InvcreateCtr',
        templateUrl: '/app/create-invoice.html',
        title: 'Invoices'
    })
    .when('/dc-print/:did', {
        controller: 'PrintCtr',
        templateUrl: '/app/dc-print.html',
        title: 'Print'
    })
    .when('/dc-edit/:id', {
        controller: 'NewDcCtr',
        templateUrl: '/app/purchase.new-dc.html',
        title: 'Delivery Challan'
    });
}])
.controller('NewDcCtr', function($q,$timeout,$filter,$http,$scope,$cacheFactory,$rootScope,$location,$routeParams,$mdToast,$mdDialog){
var iid=$routeParams.id;
var httpCache = $cacheFactory.get('$http');

$http({url: 'customers/1', method: 'GET',cache:true, ignoreLoadingBar:true}).success(function(sync){
    $scope.Customers=sync;               
});

    $http({url: 'items', method: 'GET',cache:true, ignoreLoadingBar:true}).success(function(items){
        $scope.Items=items;               
  });
    $http({ url: 'hsn', method: 'GET'}).success(function(hsn){
        $scope.Hsn=hsn;
    });


if(iid)
{
$scope.Type="Edit";
$http({url: 'dc/'+iid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(data){
$scope.details=data.details;
$scope.form2={};
$scope.form=data;
$scope.form.Dat=new Date(data.Date*1000);
$scope.form.Customer=data.CName;

});

var httpCache = $cacheFactory.get('$http');    
var cachedResponse = httpCache.get('dc/'+iid+'/edit');
if(cachedResponse)
{
  $http({url: 'dc/'+iid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(sync){
        cachedResponse[1]=sync;
        httpCache.put('dc/'+iid+'/edit',cachedResponse);
        
        $scope.details=sync.details;
        $scope.form2={};
        $scope.form=sync;
        $scope.form.Dat=new Date(sync.Date*1000); 
        $scope.form.Customer=data.CName;               
  });  
}

}
else
{
$scope.Type="Create";    
$scope.details=[];
$scope.form2={};
$scope.form={Dat: new Date()};
}

$scope.query = function(searchText) {

var deferred = $q.defer();

$timeout(function() {
    var states = getStates().filter(function(state) {
        return (state.Name.toUpperCase().indexOf(searchText.toUpperCase()) !== -1 || state.CName.toUpperCase().indexOf(searchText.toUpperCase()) !== -1);
    });
    deferred.resolve(states);
}, 50);

return deferred.promise;
   

};

function getStates() {
    return $scope.Customers;
    }

function calctotal()
{   
    var qty=0;
    var meters=0;

    angular.forEach($scope.details, function(val){
        qty=qty+parseInt(val.Qty);
        meters=meters+parseInt(val.Meters);
    });

    $scope.form.Qty=qty;
    $scope.form.Meters=meters;
}

$scope.add =  function(){
    $scope.details.push(angular.copy($scope.form2));
    $scope.form2='';
    calctotal();    
}

$scope.create =  function(){
    

    $scope.form.CID=angular.copy($scope.form.Customer.CID);
    $scope.form.Date = Math.round(new Date($scope.form.Dat).getTime() / 1000);

    if($scope.Type=='Create')
    {
        newin();
    }
    else
    {
        updatein();
    }

     
}

function newin()
{
    if($scope.details.length>0)
    {

    if($scope.submitbutton==false)    
    {
        return;
    }
    $scope.submitbutton=false;

    $http({ url: 'dc', method: 'POST',data:{invoice:$scope.form,details:$scope.details}}).success(function(data){
        al('Dc created Successfully');
    $location.path('/dc');

    }).error(function(data,status){
        $scope.submitbutton=true;
        $scope.formError=data;
    }); 
    }
    else
    {
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: 'Add atleast one record',
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    }
}

function updatein()
{
    if($scope.details.length>0)
    {
    $http({ url: 'dc/'+$scope.form.DCID, method: 'PUT',data:{invoice:$scope.form,details:$scope.details}}).success(function(data){
        al('Dc Updated Successfully');
    $location.path('/dc');

    }).error(function(data,status){
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: data,
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    });
    }
    else
    {
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: 'Add Atleast One Detail',
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    }
}

$scope.delete =  function(index){

    $scope.details.splice(index,1);
    calctotal();
}

function al(text)
{
    $mdToast.show($mdToast.simple().textContent(text).position('bottom right').hideDelay(3000));
}

var dialog = {scope:$scope, preserveScope: true, controller: function($scope, $mdDialog){$scope.hide=function(){$mdDialog.hide(); if($scope.Type=='Edit'){$scope.custform="";}$scope.formError='';};}, clickOutsideToHide:true};


$scope.createNewCustomer =  function(ev){
    // $scope.Type='Create';
    $scope.formError='';
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/new-customer.html';
    $mdDialog.show(dialog);
}

$scope.createCustomer = function()
{    
    var custform=angular.copy($scope.custform);
    $http({ url: 'customers', method: 'POST',data:custform}).success(function(data){
        al('Customer created Successfully');
    $mdDialog.hide();
    $scope.custform='';
    $scope.Customers.push(data);
    var cachedResponse = httpCache.get('customers/1');
    cachedResponse[1]=$scope.data;
    httpCache.put('customers/1',cachedResponse);
    $scope.form.Customer=data;
    }).error(function(data,status){
        $scope.formError=data;
    });
}

$scope.itemquery = function(itemText) {
var deferred = $q.defer();
var states = $scope.Items.filter(function(state) {
    return (state.IName.toUpperCase().indexOf(itemText.toUpperCase()) !== -1);
});
deferred.resolve(states);
return deferred.promise;
};


$scope.createNewItem =  function(ev){
    // $scope.Type='Create';
    $scope.formError='';
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/new-item.html';
    $mdDialog.show(dialog);
}

$scope.customerchange = function()
{
    if(angular.isDefined($scope.form.Customer)&&$scope.form.Customer!=null)
    {        
        $scope.form.CID=angular.copy($scope.form.Customer.CID);
        $scope.form.State=angular.copy($scope.form.Customer.State);
        $( "#vno" ).focus();
    }

}
$scope.itemchange = function()
{
    if(angular.isDefined($scope.form2.Item)&&$scope.form2.Item!=null)
    {        
        $scope.form2.ITID=angular.copy($scope.form2.Item.ITID);
        $scope.form2.IName=angular.copy($scope.form2.Item.IName);
        $scope.form2.HSN=angular.copy($scope.form2.Item.HSN);
        $scope.form2.Rate=angular.copy($scope.form2.Item.SRate);
        $scope.form2.GST=angular.copy($scope.form2.Item.GST);
        $( "#qty" ).focus();
    }
}
$scope.gstchange = function()
{
    $scope.details=[];
    calctotal();
}


$scope.createItem =  function()
{    
    var form=angular.copy($scope.form);
    $http({ url: 'items', method: 'POST',data:form}).success(function(data){
        al('Item created Successfully');
    $mdDialog.hide();
    $scope.form='';
    $scope.Items.push(data);

    var cachedResponse = httpCache.get('items');
    cachedResponse[1]=$scope.Items;
    httpCache.put('items',cachedResponse);
    $scope.form2.Item=data;
    }).error(function(data,status){
        $scope.formError=data;
    });
}



})
.controller('DcCtr', function($route,$q,$timeout,$filter,$http,$scope,$cacheFactory,$rootScope,$location){
$http({url: 'customers/1', method: 'GET',cache:true, ignoreLoadingBar:true}).success(function(sync){
    $scope.Customers=sync;               
});
$http({ url: 'hsn/hsn', method: 'GET'}).success(function(hsn){
    $scope.GST=hsn;
});

$scope.query = function(searchText) {

var deferred = $q.defer();

$timeout(function() {
    var states = getStates().filter(function(state) {
        return (state.Name.toUpperCase().indexOf(searchText.toUpperCase()) !== -1 || state.CName.toUpperCase().indexOf(searchText.toUpperCase()) !== -1);
    });
    deferred.resolve(states);
}, 50);

return deferred.promise;
   

};

function getStates() {
    return $scope.Customers;
    }

    $scope.mainGridOptions = {
                dataSource: {
                    transport: {
                        read: "/dc",
                        create: {
                         cache: true
                       }
                    },
                    schema: {
                        data: "data", 
                        total: "total"
                    },
                    sort: {
                        field: "DcNo",
                        dir: "desc"
                    },
                    height: 550,
                    groupable: true,
                    pageSize: 10,
                    serverFiltering: true,
                    serverPaging: true,
                    serverSorting: true,
                    // filter: { Status:"Payable" },                    
                },
                sortable: true,                
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
                
                columns: [{
                    template: '<md-checkbox style="margin-bottom:0px;" id="{{dataItem.DCID}}" value="{{dataItem.DCID}}" ng-checked="selection[dataItem.DCID]" ng-click="toggleSelection(dataItem)" ng-if="search.CID&&!search.Status"></md-checkbox>',
                    title: "",
                    width: "80px"
                    },{
                    field: "DcNo",
                    title: "DC No",
                    width: "120px"
                    },{
                    template: '{{#: Date #*1000|date:"dd-MM-yyyy"}}',
                    field: "Date",
                    title: "Date",
                    width: "120px"
                    },{
                    template: '<a href="\\#/customers/#: CID #" > #: CName # - #: Mobile1 #</a>',
                    field: "CName",
                    title: "Company"
                    // },{
                    // field: "Description"
                    },{
                    field: "Meters",
                    width: "130px",
                    title: "Meters"
                    },{
                    field: "Qty",
                    width: "130px",
                    title: "Qty"
                    },{
                    title: "Vechile No",
                    field: "VNo",
                    width: "130px"
                    },{
                    template:'<ul class="icons-list"><li class="dropdown"><a href="\\#/dc-edit/{{dataItem.DCID}}" class="dropdown-toggle md-primary" data-toggle="dropdown"><i class="glyphicon glyphicon-edit"></i></a></li><li class="dropdown"><a href="\\#/dc-print/{{dataItem.DCID}}" class="dropdown-toggle"  md-colors="{color: \'pink\'}" data-toggle="dropdown"><i class="glyphicon glyphicon-print"></i></a></li></ul>',
                    title: "Actions",
                    width: "90px"
                }]
            };
            
$scope.search={};

$scope.searchform =  function(){

    var grid = $("#grid").data("kendoGrid");
    $scope.search.FromDate = Math.round(new Date($scope.FromDat).getTime() / 1000);
    $scope.search.ToDate = Math.round(new Date($scope.ToDat).getTime() / 1000);
    if($scope.search.Customer)
    {
    $scope.search.CID=angular.copy($scope.search.Customer.CID);
    }
    grid.dataSource.filter($scope.search);
 
}

$scope.reset =  function(){
    $route.reload();
 
}

$scope.newinvoice = function()
{
    var send=[];
    angular.forEach($scope.selection, function(val){
        send.push(val.DCID);
    });

    var httpCache = $cacheFactory.get('$http');    
    httpCache.put('dcconvert',{DCID:send,GST:$scope.form.GST,CID:$scope.search.CID});
    $location.path('/dc-invoice/dc');
}

$scope.myhref = function(href)
{
    $location.path(href);
}


$scope.selection=[];
$scope.selected=[];

$scope.toggleSelection = function toggleSelection(sid) {

     if ($scope.selection[sid.DCID]) {
        delete $scope.selection[sid.DCID];
        $scope.selected.splice($scope.selected.indexOf(sid),1);
     }
     else {
       $scope.selection[sid.DCID]=sid;
        $scope.selected.push(sid);
     }
};

});