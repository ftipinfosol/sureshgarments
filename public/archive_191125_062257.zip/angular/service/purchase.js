app.config(['$routeProvider',function($routeProvider) {        
    $routeProvider.when('/suppliers', {
        controller: 'SupplierCtr',
        templateUrl: '/app/suppliers.html',
        title: 'Suppliers'
    })
    .when('/create-po', {
        controller: 'PocreateCtr',
        templateUrl: '/app/create-po.html',
        title: 'Purchase'
    })
    .when('/po', {
        controller: 'PoCtr',
        templateUrl: '/app/po.html',
        title: 'Purchase'
    })
    .when('/po-edit/:id', {
        controller: 'PocreateCtr',
        templateUrl: '/app/create-po.html',
        title: 'Purchase'
    });
}])
.controller('PocreateCtr', function($mdDialog, $filter,$q,$timeout, $http,$scope,$cacheFactory,ngTableParams,$mdToast,$mdDialog,$location,$routeParams){

var iid=$routeParams.id;
var httpCache = $cacheFactory.get('$http');    
$scope.form2={};
$http({url: 'suppliers/1', method: 'GET',cache:true, ignoreLoadingBar:true}).success(function(sync){
    $scope.Suppliers=sync;               
});
$http({url: 'items', method: 'GET',cache:true, ignoreLoadingBar:true}).success(function(items){
    $scope.Items=items;               
});

if(iid)
{
$scope.Type="Edit";
$http({url: 'purchase/'+iid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(data){
$scope.details=data.details;
$scope.form=data;
$scope.form.Dat=new Date(data.Date*1000);
$scope.form.Du=new Date(data.Due*1000);
$scope.form.Supplier = $filter('filter')($scope.Suppliers, {SID:angular.copy(parseInt(data.SID))}, true)[0];
if(data.details[0].RIGST==0)
{
    $scope.form.GST=data.details[0].RCGST*2;
}
else
{
    $scope.form.GST=data.details[0].RIGST;
}
});

var cachedResponse = httpCache.get('purchase/'+iid+'/edit');
if(cachedResponse)
{
  $http({url: 'purchase/'+iid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(sync){
        cachedResponse[1]=sync;
        httpCache.put('purchase/'+iid+'/edit',cachedResponse);        
        $scope.details=sync.details;
        $scope.form=sync;
        $scope.form.Dat=new Date(sync.Date*1000); 
        $scope.form.Du=new Date(sync.Due*1000);
  });  
}
}
else
{
$scope.Type="Create";    
$scope.details=[];
$scope.form={Dat: new Date(),Du: new Date()};
}

$scope.query = function(searchText) {
var deferred = $q.defer();
$timeout(function() {
    var states = getStates().filter(function(state) {
        return (state.Name.toUpperCase().indexOf(searchText.toUpperCase()) !== -1 || state.CName.toUpperCase().indexOf(searchText.toUpperCase()) !== -1);
    });
    deferred.resolve(states);
}, 0);
return deferred.promise;
};

function getStates() {
return $scope.Suppliers;
}


$scope.create =  function(){
    
    $scope.form.Date = Math.round(new Date($scope.form.Dat).getTime() / 1000);
    $scope.form.Due = Math.round(new Date($scope.form.Du).getTime() / 1000);
    if($scope.Type=='Create')
    {
        newin();
    }
    else
    {
        updatein();
    }

     
}

function newin()
{
    if($scope.details.length>0&&$scope.form.Total)
    {

    if($scope.submitbutton==false)    
    {
        return;
    }
    $scope.submitbutton=false;

    $http({ url: 'purchase', method: 'POST',data:{purchase:$scope.form,details:$scope.details}}).success(function(data){
        al('PO created Successfully');
    $location.path('/po');

    }).error(function(data,status){
        $scope.formError=data;
        $scope.submitbutton=true;
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: data,
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    }); 
    }
    else
    {
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: 'Add atleast one record',
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    }
}

function updatein()
{
    if($scope.details.length>0)
    {
    $http({ url: 'purchase/'+$scope.form.POID, method: 'PUT',data:{purchase:$scope.form,details:$scope.details}}).success(function(data){
        al('PO Updated Successfully');
    $location.path('/po');

    }).error(function(data,status){
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: data,
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    });
    }
    else
    {
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: 'Add atleast one record',
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    }
}


$scope.delete =  function(index){
    $scope.details.splice(index,1);
    calctotal();
}

$scope.edit =  function(index){

    $scope.form2=$scope.details[index];
    $scope.curedit=index;
}

$scope.save =  function(index){

    $scope.details[index]=angular.copy($scope.form2);
    $scope.form2="";
    $scope.curedit=undefined;
    calctotal();
}


function al(text)
{
    $mdToast.show($mdToast.simple().textContent(text).position('bottom right').hideDelay(3000));
}

var dialog = {scope:$scope, preserveScope: true, controller: function($scope, $mdDialog){$scope.hide=function(){$mdDialog.hide(); if($scope.Type=='Edit'){$scope.custform="";}$scope.formError='';};}, clickOutsideToHide:true};


$scope.createNewCustomer =  function(ev){
    $scope.Type='New';
    $scope.formError='';
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/new-supplier.html';
    $mdDialog.show(dialog);
}

$scope.createCustomer = function()
{    
    var custform=angular.copy($scope.custform);
    $http({ url: 'suppliers', method: 'POST',data:custform}).success(function(data){
        al('Supplier created Successfully');
    $mdDialog.hide();
    $scope.custform='';
    $scope.Suppliers.push(data);
    var cachedResponse = httpCache.get('suppliers/1');
    cachedResponse[1]=$scope.data;
    httpCache.put('suppliers/1',cachedResponse);
    $scope.form.Supplier=data;
    }).error(function(data,status){
        $scope.formError=data;
    });
}

$scope.itemquery = function(itemText) {
var deferred = $q.defer();
var states = $scope.Items.filter(function(state) {
    return (state.IName.toUpperCase().indexOf(itemText.toUpperCase()) !== -1);
});
deferred.resolve(states);
return deferred.promise;
};


$scope.createNewItem =  function(ev){
    $scope.Type='New';
    $scope.formError='';
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/new-item.html';
    $mdDialog.show(dialog);
}

$scope.customerchange = function()
{
    if(angular.isDefined($scope.form.Supplier)&&$scope.form.Supplier!=null)
    {        
        $scope.form.SID=angular.copy($scope.form.Supplier.SID);
        $scope.form.State=angular.copy($scope.form.Supplier.State);
        $scope.calcdetails();
    }

}

$scope.inamechange = function()
{
    if(!$scope.form2.IName)
    {        
        $scope.form2.Item = undefined;
    }
}

$scope.itemchange = function()
{
    if(angular.isDefined($scope.form2.Item)&&$scope.form2.Item!=null)
    {        
        $scope.form2.ITID=angular.copy($scope.form2.Item.ITID);
        $scope.form2.IName=angular.copy($scope.form2.Item.IName);
        $scope.form2.HSN=angular.copy($scope.form2.Item.HSN);
        $scope.form2.Rate=angular.copy($scope.form2.Item.SRate);
        $scope.form2.GST=angular.copy($scope.form2.Item.GST);
        $scope.calc();
        $( "#qty" ).focus();
    }
}
$scope.gstchange = function()
{
    $scope.details=[];
    calctotal();
}


$scope.createItem =  function()
{    
    var form=angular.copy($scope.form);
    $http({ url: 'items', method: 'POST',data:form}).success(function(data){
        al('Item created Successfully');
    $mdDialog.hide();
    $scope.form='';
    $scope.Items.push(data);

    var cachedResponse = httpCache.get('items');
    cachedResponse[1]=$scope.Items;
    httpCache.put('items',cachedResponse);
    $scope.form2.Item=data;
    }).error(function(data,status){
        $scope.formError=data;
    });
}


$scope.calc =  function(){
    if($scope.form.Supplier==undefined||$scope.form.Supplier==null)
    {
        var confirm = $mdDialog.alert({
            title: 'Warning',
            textContent: 'Select Supplier',
            ok: 'Close'
          });
        $mdDialog.show(confirm);
        $scope.form2.Rate=0;
        $scope.form2.Qty=0;
        $scope.form2.Taxable=0;
        return;
    }
    $scope.form2.Amount=Math.round(parseFloat($scope.form2.Rate)*parseFloat($scope.form2.Qty)*100)/100;
    if($scope.form.State==32)
    {
        $scope.form2.RCGST=angular.copy($scope.form2.GST/2);
        $scope.form2.RSGST=angular.copy($scope.form2.GST/2);
        $scope.form2.RIGST=0;
        var gst = angular.copy(($scope.form2.Amount*$scope.form2.RCGST)/100);
        $scope.form2.CGST=gst;
        $scope.form2.SGST=gst;
        $scope.form2.IGST=0;
    }
    else
    {
        $scope.form2.RCGST=0;
        $scope.form2.RSGST=0;
        $scope.form2.RIGST=angular.copy($scope.form2.GST);
        var gst = angular.copy(($scope.form2.Amount*$scope.form2.RIGST)/100);
        $scope.form2.CGST=0;
        $scope.form2.SGST=0;
        $scope.form2.IGST=gst;
    }
     $scope.form2.Total=$scope.form2.Amount+$scope.form2.CGST+$scope.form2.SGST+$scope.form2.IGST;   

}

$scope.calcdetails =  function(){
    console.log($scope.form.Supplier.SID);

    if($scope.form.Supplier==undefined||$scope.form.Supplier==null)
    {
        return;
    }    

     angular.forEach($scope.details, function(val,key){
            if($scope.form.State==32)
            {
                val.RCGST=angular.copy(val.GST/2);
                val.RSGST=angular.copy(val.GST/2);
                val.RIGST=0;
                var gst = angular.copy((val.Amount*val.RCGST)/100);
                val.CGST=gst;
                val.SGST=gst;
                val.IGST=0;
            }
            else
            {
                val.RCGST=0;
                val.RSGST=0;
                val.RIGST=angular.copy(val.GST);
                var gst = angular.copy((val.Amount*val.RIGST)/100);
                val.CGST=0;
                val.SGST=0;
                val.IGST=gst;
            }
            val.Total=val.Amount*1+val.CGST+val.SGST+val.IGST;
            $scope.details[key]=val;
    });
     calctotal();
   

}


$scope.add =  function(){
    if($scope.form2.Amount&&$scope.form2.Qty>0)
    {
       $scope.details.push(angular.copy($scope.form2));
       $scope.form2='';
       calctotal(); 
    }    
}

function calctotal()
{   
    var qty=0;
    var amount=0;
    var cgst=0;
    var sgst=0;
    var igst=0;
    var round=0;

    angular.forEach($scope.details, function(val){
        qty=qty+parseInt(val.Qty);
        amount=amount+parseFloat(val.Amount);
        cgst=cgst+parseFloat(val.CGST);
        sgst=sgst+parseFloat(val.SGST);
        igst=igst+parseFloat(val.IGST);
    });
    var total = Math.round(amount+cgst+sgst+igst);
    round=Math.round((total-(amount+cgst+sgst+igst))*100)/100;

    $scope.form.Qty=qty
    $scope.form.Amount=amount;
    $scope.form.CGST=cgst;
    $scope.form.SGST=sgst;
    $scope.form.IGST=igst;
    $scope.form.Total=total;
    $scope.form.Round=round;
    $scope.form.Balance=total;
}


})
.controller('SupplierCtr', function($window,$http,$scope,$cacheFactory,ngTableParams,$mdToast,$mdDialog,$rootScope,$route){
var httpCache = $cacheFactory.get('$http');
var path;
var dialog = {scope:$scope, preserveScope: true, controller: function($scope, $mdDialog){$scope.hide=function(){$mdDialog.hide(); if($scope.Type=='Edit'){$scope.custform="";}$scope.formError='';};}, clickOutsideToHide:true};
$scope.data=[];
$scope.tableSorting = new ngTableParams({
    page: 1,
    count: 10,
    sorting: {
        SID: 'desc'
    }
    }, {
    total: $scope.data.length, 
    getData: function($defer, params) {
        $rootScope.isLoading=true;
        path = 'suppliers?'+jQuery.param({
        "skip": (params.page() - 1) * params.count(),
        "take": params.count(),
        "filter":params.filter(),
        "orderBy": params.sorting()});

        $http({ cache: true, url: path, method: 'GET'})
        .success(function (result) {
            $scope.data = result.data;
            params.total(result.total);
            $defer.resolve(result.data);
            $rootScope.isLoading=false;
        }); 

        var cachedResponse = httpCache.get(path);
        if(cachedResponse)
        {
          $http({url: path, method: 'GET', ignoreLoadingBar:true}).success(function(sync){
                cachedResponse[1]=sync;
                httpCache.put(path,cachedResponse);
                $scope.data = sync.data;
                params.total(sync.total);
                $defer.resolve(sync.data); 
                $rootScope.isLoading=false;                  
          });  
        } 
    }
})

$scope.searchform =  function(){
 angular.extend($scope.tableSorting.filter(), $scope.search);   
}

$scope.campcreate =  function(ev){
    $scope.Type='New';
    $scope.formError='';
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/new-supplier.html';
    $mdDialog.show(dialog);
}

$scope.campedit =  function(cid,index,ev){
    $scope.custform="";    
    $scope.Type='Edit';
    $scope.formError='';
    $scope.curid=index;
    angular.forEach($scope.data, function(val){
        if(val.SID==cid)
        { $scope.custform=angular.copy(val); }
    });
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/new-supplier.html';
    $mdDialog.show(dialog);
}

$scope.delete =  function(cid,index,ev){
    var confirm = $mdDialog.confirm({targetEvent:ev})
          .title('Are You sure to delete this Supplier?')
          .ok('Yes')
          .cancel('No');

    $mdDialog.show(confirm).then(function() {
            $http({ url: 'suppliers/'+cid, method: 'DELETE'}).success(function(data){
                al('Deleted Successfully');
                $scope.data.splice(index,1);
                }).error(function(data,status){
                    al('This Supplier has po in use. Cant Delate');
                });
    }, function() {
        al('Delete Cancelled');
    });
}

$scope.createCustomer =  function(){
    if($scope.Type=='New')
    {
        add();
    }
    else
    {
        update();
    }
}
function add()
{    
    var custform=angular.copy($scope.custform);
    $http({ url: 'suppliers', method: 'POST',data:custform}).success(function(data){
        al('Supplier created Successfully');
    $mdDialog.hide();
    $scope.custform='';
    $scope.data.push(data);
    }).error(function(data,status){
        $scope.formError=data;
    });
}

function update()
{    
    var custform=angular.copy($scope.custform);
    $http({ url: 'suppliers/'+$scope.custform.SID, method: 'PUT',data:custform}).success(function(data){
        al('Supplier Details Updated Successfully');
    $mdDialog.hide();
    $scope.custform='';
    $scope.data[$scope.curid]=data;
    }).error(function(data,status){
        $scope.formError=data;
    });
}

function al(text)
{
    $mdToast.show($mdToast.simple().textContent(text).position('bottom right').hideDelay(3000));
}

})
.controller('PoCtr', function($http,$scope,$cacheFactory,ngTableParams,$mdToast,$mdDialog,$rootScope,$location){

var httpCache = $cacheFactory.get('$http');
var path;
var dialog = {scope:$scope, preserveScope: true, controller: function($scope, $mdDialog){$scope.hide=function(){$mdDialog.hide(); if($scope.Type=='Edit'){$scope.custform="";}$scope.formError='';};}, clickOutsideToHide:true};
$scope.data=[];
$scope.tableSorting = new ngTableParams({
    page: 1,
    count: 10,
    sorting: {
        PoNo: 'desc'
    }
    }, {
    total: $scope.data.length, 
    getData: function($defer, params) {
        $rootScope.isLoading=true;
        path = 'purchase?'+jQuery.param({
        "skip": (params.page() - 1) * params.count(),
        "take": params.count(),
        "filter":params.filter(),
        "orderBy": params.sorting()});

        $http({ cache: true, url: path, method: 'GET'})
        .success(function (result) {
            $scope.data = result.data;
            params.total(result.total);
            $defer.resolve(result.data);
            $rootScope.isLoading=false;
        }); 

        var cachedResponse = httpCache.get(path);
        if(cachedResponse)
        {
          $http({url: path, method: 'GET', ignoreLoadingBar:true}).success(function(sync){
                cachedResponse[1]=sync;
                httpCache.put(path,cachedResponse);
                $scope.data = sync.data;
                params.total(sync.total);
                $defer.resolve(sync.data); 
                $rootScope.isLoading=false;                  
          });  
        } 
    }
})


$scope.delete =  function(cid,index,ev){
    var confirm = $mdDialog.confirm({targetEvent:ev})
          .title('Are You sure to delete this PO?')
          .ok('Yes')
          .cancel('No');

    $mdDialog.show(confirm).then(function() {
            $http({ url: 'purchase/'+cid, method: 'DELETE'}).success(function(data){
                al('Deleted Successfully');
                $scope.data.splice(index,1);
                }).error(function(data,status){
                    al('Cant Delete');
                });
    }, function() {
        al('Delete Cancelled');
    });
}

$scope.convert =  function(cid,index,ev){
    var confirm = $mdDialog.confirm({targetEvent:ev})
          .title('Are You sure to Convert this PO?')
          .ok('Yes')
          .cancel('No');

    $mdDialog.show(confirm).then(function() {
            $http({ url: 'purchase/'+cid}).success(function(data){
                al('Converted Successfully');
                $scope.data[index]=data;
                }).error(function(data,status){
                    al('Cant Convert');
                });
    }, function() {
        al('Convert Cancelled');
    });
}

function al(text)
{
    $mdToast.show($mdToast.simple().textContent(text).position('bottom right').hideDelay(3000));
}
            
$scope.search={};

$scope.searchform =  function(){
    $scope.search.FromDate = Math.round(new Date($scope.FromDat).getTime() / 1000);
    $scope.search.ToDate = Math.round(new Date($scope.ToDat).getTime() / 1000);
    angular.extend($scope.tableSorting.filter(), $scope.search);  
}

});
app.run(['$rootScope', function($rootScope) {
    $rootScope.$on("$routeChangeSuccess", function(event, currentRoute, previousRoute) {
    $rootScope.title = currentRoute.title;
    });
}]);