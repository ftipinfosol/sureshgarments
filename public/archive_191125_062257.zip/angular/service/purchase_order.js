app.config(['$routeProvider',function($routeProvider) {        
    $routeProvider
    .when('/create-purchase-order', {
        controller: 'PurchaseordercreateCtr',
        templateUrl: '/app/create-purchase-order.html',
        title: 'Purchase Order'
    })
    .when('/regen/:rid', {
        controller: 'PurchaseordercreateCtr',
        templateUrl: '/app/create-purchase-order.html',
        title: 'Purchase Order'
    })
    .when('/purchase-order', {
        controller: 'PurchaseOrderCtr',
        templateUrl: '/app/purchase-order.html',
        title: 'Purchase Order'
    })
    .when('/purchase-order-edit/:id', {
        controller: 'PurchaseordercreateCtr',
        templateUrl: '/app/create-purchase-order.html',
        title: 'Edit Purchase Order'
    })
    .when('/po-print/:id', {
        controller: 'POPrintCtr',
        templateUrl: '/app/po-print.html',
        title: 'Purchase order Print'
    });
}])

.controller('PurchaseordercreateCtr', function($rootScope,$mdDialog, $filter,$q,$timeout, $http,$scope,$cacheFactory,ngTableParams,$mdToast,$mdDialog,$location,$routeParams){

var iid=$routeParams.id;
var rid=$routeParams.rid;
var dc=$routeParams.dc;
var httpCache = $cacheFactory.get('$http');    
$scope.form2={};
$scope.multiple=false;

  $http({url: 'suppliers/1', method: 'GET', ignoreLoadingBar:true}).success(function(sync){
        $scope.Suppliers=sync;               
  });
    $http({url: 'items', method: 'GET', ignoreLoadingBar:true}).success(function(items){
        $scope.Items=items;               
  });

    $http({ url: 'hsn/hsn', method: 'GET'}).success(function(hsn){
        $scope.GST=hsn;

    });

if(iid)
{
$scope.Type="Edit";
$http({url: 'purchase-order/'+iid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(data){
$scope.details=data.details;

$scope.form=data;
$scope.form.Dat=new Date(data.Date*1000);
$scope.form.Du=new Date(data.Due*1000);
$scope.form.Supplier = $filter('filter')($scope.Suppliers, {SID:angular.copy(parseInt(data.SID))}, true)[0];
// $scope.form.Supplier=data.CName;
if(data.details[0].RIGST==0)
{
    $scope.form.GST=data.details[0].RCGST*2;
}
else
{
    $scope.form.GST=data.details[0].RIGST;
}
});

$scope.data=print.data;
var cachedResponse = httpCache.get('purchase-order/'+iid+'/edit');
if(cachedResponse)
{
  $http({url: 'purchase-order/'+iid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(sync){
        cachedResponse[1]=sync;
        httpCache.put('purchase-order/'+iid+'/edit',cachedResponse);
        
        $scope.details=sync.details;
        $scope.form=sync;
        $scope.form.Dat=new Date(sync.Date*1000); 
        $scope.form.Du=new Date(sync.Due*1000); 
        $scope.form.Supplier=data.CName;    
                      

  });  
}

}
else
{
$scope.Type="Create";    
$scope.details=[];
$scope.form={Dat: new Date(),Delivery_Dat: new Date(),Du: new Date(),Disc:0};
}


if(dc)
{
    $scope.fromdc=true;
    var httpCache = $cacheFactory.get('$http');    
    var cachedResponse = httpCache.get('dcconvert');
    if(cachedResponse)
    {
        $scope.form.GST=angular.copy(cachedResponse.GST);    
        $http({url: 'dcdetails?GST='+cachedResponse.GST+'&ids='+cachedResponse.DCID, method: 'GET', ignoreLoadingBar:true}).success(function(details){        
            angular.forEach(details, function(val){
                val.IName=val.Des;
                val.Qty=angular.copy(val.Meters);
                val.Amount=Math.round(parseFloat(val.Rate)*parseFloat(val.Meters)*100)/100;
                $scope.details.push(val);
            }); 
            $scope.form.Supplier = $filter('filter')($scope.supplier, {SID:angular.copy(parseInt(cachedResponse.SID))}, true)[0];
        });
    }
    else
    {
        $location.path('/dc');        
    }
    $scope.form.Dat=new Date(); 
    $scope.form.Du=new Date(); 


}

$scope.query = function(searchText) {
var deferred = $q.defer();
$timeout(function() {
    var states = getStates().filter(function(state) {
        return (state.Name.toUpperCase().indexOf(searchText.toUpperCase()) !== -1 || state.CName.toUpperCase().indexOf(searchText.toUpperCase()) !== -1);
    });
    deferred.resolve(states);
}, 0);
return deferred.promise;
};

function getStates() {
    return $scope.Suppliers;
    }


$scope.fill =  function(){

        angular.forEach($scope.dc, function(val){
            if(val.DcNo==$scope.form2.Dc)
            {
                var curdata=angular.copy(val);
                $scope.form2.Date=$filter('date')(curdata.Date*1000, "dd-MM-yyyy");
                $scope.form2.Dat=curdata.Date;
                $scope.form2.Des=curdata.Description;
                $scope.form2.Qty=curdata.TotMeters;
            }
        });
}

$scope.create =  function(){
    
    $scope.form.Delivery_Date = Math.round(new Date($scope.form.Delivery_Dat).getTime() / 1000);
    $scope.form.Date = Math.round(new Date($scope.form.Dat).getTime() / 1000);

    var date = new Date($scope.form.Dat);
    date.setDate(date.getDate() + $rootScope.Authuser.Due*1);
    $scope.form.Due = Math.round(date.getTime() / 1000);

    if($scope.Type=='Create')
    {
        if(rid)
        {
           $scope.form.RID=rid; 
        }
        newin();
    }
    else
    {
        updatein();
    }

     
}

function newin()
{
    if($scope.details.length>0&&$scope.form.Total)
    {

    if($scope.submitbutton==false)    
    {
        return;
    }
    $scope.submitbutton=false;

    $http({ url: 'purchase-order', method: 'POST',data:{invoice:$scope.form,details:$scope.details}}).success(function(data){
        al('Purchase Order created Successfully');
    $location.path('/purchase-order');

    }).error(function(data,status){
        $scope.formError=data;
        $scope.submitbutton=true;
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: data,
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    }); 
    }
    else
    {
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: 'Add atleast one record',
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    }
}

function updatein()
{
    if($scope.details.length>0)
    {
    $http({ url: 'purchase-order/'+$scope.form.PODRID, method: 'PUT',data:{invoice:$scope.form,details:$scope.details}}).success(function(data){
        al('Purchase Order Updated Successfully');
    $location.path('/purchase-order');

    }).error(function(data,status){
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: data,
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    });
    }
    else
    {
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: 'Add atleast one record',
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    }
}

$scope.cancel =  function(status){

   $http({ url: 'invoice-st', method: 'POST',data:{IID:$scope.form.IID,Status:status}}).success(function(data){
        $scope.form.Status=data.Status;
        al('Status changed Successfully');
    }).error(function(data,status){
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: data,
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    });
}

$scope.delete =  function(index){
    $scope.details.splice(index,1);
    calctotal();
}

$scope.edit =  function(index){

    $scope.form2=angular.copy($scope.details[index]);
    $scope.form2.Item = $filter('filter')($scope.Items, {ITID:angular.copy(parseInt($scope.form2.ITID))}, true)[0];
    $scope.curedit=index;
}

$scope.save =  function(index){

    $scope.details[$scope.curedit]=angular.copy($scope.form2);
    $scope.form2="";
    $scope.curedit=undefined;
    calctotal();
}


function al(text)
{
    $mdToast.show($mdToast.simple().textContent(text).position('bottom right').hideDelay(3000));
}

var dialog = {scope:$scope, preserveScope: true, controller: function($scope, $mdDialog){$scope.hide=function(){$mdDialog.hide(); if($scope.Type=='Edit'){$scope.custform="";}$scope.formError='';};}, clickOutsideToHide:true};


$scope.invoicedetails =  function(ev){
    $scope.formError='';
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/invoicedetails.html';
    $mdDialog.show(dialog);
}

$scope.createNewCustomer =  function(ev){
    // $scope.Type='New';
    $scope.formError='';
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/new-supplier.html';
    $mdDialog.show(dialog);
}

$scope.createCustomer = function()
{    
    var custform=angular.copy($scope.custform);
    $http({ url: 'supplier', method: 'POST',data:custform}).success(function(data){
        al('Supplier created Successfully');
    $mdDialog.hide();
    $scope.custform='';
    $scope.Suppliers.push(data);
    var cachedResponse = httpCache.get('supplier/1');
    cachedResponse[1]=$scope.data;
    httpCache.put('supplier/1',cachedResponse);
    $scope.form.Supplier=data;
    }).error(function(data,status){
        $scope.formError=data;
    });
}

$scope.itemquery = function(itemText) {
var deferred = $q.defer();
var states = getitem().filter(function(state) {
    return (state.IName.toUpperCase().indexOf(itemText.toUpperCase()) !== -1);
});
deferred.resolve(states);
return deferred.promise;
};

function getitem()
{
    if($scope.form.GST==undefined||$scope.form.GST=='')
    {
        return [];
    }
    return $filter('filter')($scope.Items, {GST:angular.copy(parseInt($scope.form.GST))}, true);

}

$scope.createNewItem =  function(ev){
    $scope.formError='';
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/new-item.html';
    $mdDialog.show(dialog);
}

$scope.customerchange = function()
{
    if(angular.isDefined($scope.form.Supplier)&&$scope.form.Supplier!=null)
    {        
        $scope.form.SID=angular.copy($scope.form.Supplier.SID);
        $scope.form.State=angular.copy($scope.form.Supplier.State);
        $scope.calcdetails();
        $("#vno" ).focus();
    }

}

$scope.inamechange = function()
{
    if(!$scope.form2.IName)
    {        
        $scope.form2.Item = undefined;
    }
}

$scope.itemchange = function()
{
    if(angular.isDefined($scope.form2.Item)&&$scope.form2.Item!=null)
    {        
        $scope.form2.ITID=angular.copy($scope.form2.Item.ITID);
        $scope.form2.IName=angular.copy($scope.form2.Item.IName);
        $scope.form2.HSN=angular.copy($scope.form2.Item.HSN);
        $scope.form2.Rate=angular.copy($scope.form2.Item.SRate);
        $scope.form2.GST=angular.copy($scope.form2.Item.GST);
        $scope.form2.Unit=angular.copy($scope.form2.Item.Unit);
        $scope.calc();
    }
     $( "#unit" ).focus();
}
$scope.gstchange = function()
{
    if($scope.form.Supplier==undefined||$scope.form.Supplier==null)
    {
        return;
    }    

     angular.forEach($scope.details, function(val,key){
            if($scope.form.State==32)
            {
                val.RCGST=angular.copy($scope.form.GST/2);
                val.RSGST=angular.copy($scope.form.GST/2);
                val.RIGST=0;
                var gst = angular.copy((val.Amount*val.RCGST)/100);
                val.CGST=gst;
                val.SGST=gst;
                val.IGST=0;
            }
            else
            {
                val.RCGST=0;
                val.RSGST=0;
                val.RIGST=angular.copy($scope.form.GST);
                var gst = angular.copy((val.Amount*val.RIGST)/100);
                val.CGST=0;
                val.SGST=0;
                val.IGST=gst;
            }
            val.Total=val.Amount*1+val.CGST+val.SGST+val.IGST;
            $scope.details[key]=val;
    });
     calctotal();
}


$scope.createItem =  function()
{    
    var form=angular.copy($scope.form);
    $http({ url: 'items', method: 'POST',data:form}).success(function(data){
        al('Item created Successfully');
    $mdDialog.hide();
    $scope.form='';
    $scope.Items.push(data);

    var cachedResponse = httpCache.get('items');
    cachedResponse[1]=$scope.Items;
    httpCache.put('items',cachedResponse);
    $scope.form2.Item=data;
    }).error(function(data,status){
        $scope.formError=data;
    });
}


$scope.calc =  function(){
    if($scope.form.Supplier==undefined||$scope.form.Supplier==null)
    {
        var confirm = $mdDialog.alert({
            title: 'Warning',
            textContent: 'Select Supplier',
            ok: 'Close'
          });
        $mdDialog.show(confirm);
        $scope.form2.Rate=0;
        $scope.form2.Qty=0;
        $scope.form2.Taxable=0;
        return;
    }
    $scope.form2.Amount=Math.round(parseFloat($scope.form2.Rate)*parseFloat($scope.form2.Qty)*100)/100;
    if($scope.form.State==32)
    {
        $scope.form2.RCGST=angular.copy($scope.form2.GST/2);
        $scope.form2.RSGST=angular.copy($scope.form2.GST/2);
        $scope.form2.RIGST=0;
        var gst = angular.copy(($scope.form2.Amount*$scope.form2.RCGST)/100);
        $scope.form2.CGST=gst;
        $scope.form2.SGST=gst;
        $scope.form2.IGST=0;
    }
    else
    {
        $scope.form2.RCGST=0;
        $scope.form2.RSGST=0;
        $scope.form2.RIGST=angular.copy($scope.form2.GST);
        var gst = angular.copy(($scope.form2.Amount*$scope.form2.RIGST)/100);
        $scope.form2.CGST=0;
        $scope.form2.SGST=0;
        $scope.form2.IGST=gst;
    }
     $scope.form2.Total=$scope.form2.Amount+$scope.form2.CGST+$scope.form2.SGST+$scope.form2.IGST;   

}

$scope.calcdetails =  function(){
    if($scope.form.Supplier==undefined||$scope.form.Supplier==null)
    {
        return;
    }    

     angular.forEach($scope.details, function(val,key){
        
            if($scope.form.State==32)
            {
                val.RCGST=angular.copy(val.GST/2);
                val.RSGST=angular.copy(val.GST/2);
                val.RIGST=0;
                var gst = angular.copy((val.Amount*val.RCGST)/100);
                val.CGST=gst;
                val.SGST=gst;
                val.IGST=0;
            }
            else
            {
                val.RCGST=0;
                val.RSGST=0;
                val.RIGST=angular.copy(val.GST);
                var gst = angular.copy((val.Amount*val.RIGST)/100);
                val.CGST=0;
                val.SGST=0;
                val.IGST=gst;
            }
            val.Total=val.Amount*1+val.CGST+val.SGST+val.IGST;
            $scope.details[key]=val;
    });
     calctotal();
   

}


$scope.add =  function(){

    if ($scope.curedit!=undefined) {
        $scope.save();
        return;
    }
    // console.log($scope.curedit);
    if($scope.form2.Amount&&$scope.form2.Qty>0)
    {
       $scope.details.push(angular.copy($scope.form2));
       $scope.form2='';
       calctotal(); 
    }    
}

function calctotal()
{   
    var qty=0;
    var amount=0;
    var cgst=0;
    var sgst=0;
    var igst=0;
    var round=0;

    angular.forEach($scope.details, function(val){
        qty=qty+parseInt(val.Qty);
        amount=amount+parseFloat(val.Amount);
        cgst=cgst+parseFloat(val.CGST);
        sgst=sgst+parseFloat(val.SGST);
        igst=igst+parseFloat(val.IGST);
    });
    var total = Math.round(amount+cgst+sgst+igst);
    round=Math.round((total-(amount+cgst+sgst+igst))*100)/100;

    $scope.form.Qty=qty
    $scope.form.Amount=amount;
    $scope.form.CGST=cgst;
    $scope.form.SGST=sgst;
    $scope.form.IGST=igst;
    $scope.form.Total=total;
    $scope.form.Round=round;
    $scope.form.Balance=total;
    $scope.disc(); 

}

$scope.disc =  function(){
    console.log($scope.form.Amount);
    console.log($scope.form.Disc);
    $scope.form.DiscAmount=($scope.form.Amount*$scope.form.Disc)/100;
    console.log($scope.form.DiscAmount);

    $scope.form.SubTotal=$scope.form.Amount-$scope.form.DiscAmount;
    // console.log($scope.form.SubTotal);

    $scope.form.Total=Math.round(parseFloat($scope.form.SubTotal)+parseFloat($scope.form.CGST)+parseFloat($scope.form.SGST)+parseFloat($scope.form.IGST));
    $scope.form.Balance=angular.copy($scope.form.Total);

}



})
.controller('PurchaseOrderCtr', function($http,$scope,$cacheFactory,ngTableParams,$mdToast,$mdDialog,$rootScope,$location){

var path;
var httpCache = $cacheFactory.get('$http');

    $scope.mainGridOptions = {
                dataSource: {
                    transport: {
                        read : function (options) {

                            path = '/purchase-order?'+jQuery.param(options.data);
                            $http({ url: path, method: 'GET', cache: true}).success(function(data){
                                options.success(data);
                            });
                            var cachedResponse = httpCache.get(path);
                            if(cachedResponse)
                            {
                              $http({url: path, method: 'GET'}).success(function(sync){
                                    options.success(sync);
                                    cachedResponse[1]=sync;
                                    httpCache.put(path,cachedResponse);                 
                              });  
                            }

                            }
                    },
                    schema: {
                        data: "data", 
                        total: "total"
                    },
                    sort: {
                        field: "PodrNo",
                        dir: "desc"
                    },
                    height: 550,
                    groupable: true,
                    pageSize: 10,
                    serverFiltering: true,
                    serverPaging: true,
                    serverSorting: true,
                    filter: { Status:"" },                    
                },
                sortable: true,                
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5,
                    pageSizes: [5,10,20,50,100]
                },
                columns: [{
                    field: "PodrNo",
                    title: "PO No",
                    width: "120px"
                    },{
                    template: '{{#: Date #*1000|date:"dd-MM-yyyy"}}',
                    field: "Date",
                    title: "Date",
                    width: "120px"
                    },{
                    template: '<a href="" > #: CName # - #: Mobile1 #</a>',
                    field: "CName",
                    title: "Company"
                    },{
                    template: '{{dataItem.Total | currency : "&\\#8377; " : 2}}',
                    field: "Total",
                    width: "120px"
                    },{
                    template:'<ul class="icons-list"><li class="dropdown"><a href="\\#/purchase-order-edit/{{dataItem.PODRID}}" class="dropdown-toggle md-primary" data-toggle="dropdown"><i class="glyphicon glyphicon-edit"></i></a></li><li class="dropdown"><a href="\\#/po-print/{{dataItem.PODRID}}" class="dropdown-toggle"  md-colors="{color: \'pink\'}" data-toggle="dropdown"><i class="glyphicon glyphicon-print"></i></a></li></ul>',
                    title: "Actions",
                    width: "90px"
                }]
            };
            
$scope.search={};

$scope.searchform =  function(){

    var grid = $("#grid").data("kendoGrid");
    $scope.search.FromDate = Math.round(new Date($scope.FromDat).getTime() / 1000);
    $scope.search.ToDate = Math.round(new Date($scope.ToDat).getTime() / 1000);
    grid.dataSource.filter($scope.search);
 
}

$scope.reset =  function(){
    $scope.ToDat=null;
    $scope.FromDat=null;
    $scope.search={};
    var grid = $("#grid").data("kendoGrid");
    grid.dataSource.filter($scope.search);
 
}

})
.controller('POPrintCtr', function($mdToast,$timeout,$filter,$window,$http,$scope,$cacheFactory,ngTableParams,$mdToast,$mdDialog,$location,$routeParams,$rootScope){

var iid=$routeParams.id;
var sid=$routeParams.sid;
var did=$routeParams.did;
$scope.InvType = JSON.parse($rootScope.Authuser.InvType);
$scope.InvCur = angular.copy($scope.InvType);
var dialog = {scope:$scope, preserveScope: true, controller: function($scope, $mdDialog){$scope.hide=function(){$mdDialog.hide(); if($scope.Type=='Edit'){$scope.form="";}$scope.formError='';};}, clickOutsideToHide:true};


if(iid)
{
$http({url: 'purchase-order/'+iid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(data){
$scope.data = data; 

$timeout(function(){

$scope.tbody = angular.element("#tbody")[0].offsetHeight;
var tbody=angular.copy($scope.tbody);
if(tbody<1050)
{
    $scope.myheight={'height':(1050-tbody)+'px'};
}

},500);



});


$scope.data=print.data;
var httpCache = $cacheFactory.get('$http');    
var cachedResponse = httpCache.get('purchase-order/'+iid+'/edit');
if(cachedResponse)
{
  $http({url: 'purchase-order/'+iid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(sync){
        cachedResponse[1]=sync;
        httpCache.put('purchase-order/'+iid+'/edit',cachedResponse);
        $scope.data = sync;  

        $timeout(function(){

        $scope.tbody = angular.element("#tbody")[0].offsetHeight;
        var tbody=angular.copy($scope.tbody);
        if(tbody<1050)
        {
            $scope.myheight={'height':(1050-tbody)+'px'};
        }

        },500);

  });  
}
  
}


else if(sid)
{

$http({url: 'packing/'+sid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(data){
$scope.data = data;                  
});

$scope.data=print.data;
var httpCache = $cacheFactory.get('$http');    
var cachedResponse = httpCache.get('packing/'+sid+'/edit');
if(cachedResponse)
{
  $http({url: 'packing/'+sid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(sync){
        cachedResponse[1]=sync;
        httpCache.put('packing/'+sid+'/edit',cachedResponse);
        $scope.data = sync;                  
  });  
}
  
}

else if(did)
{

$http({url: 'dc/'+did+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(data){
$scope.data = data;                  
});

$scope.data=print.data;
var httpCache = $cacheFactory.get('$http');    
var cachedResponse = httpCache.get('dc/'+did+'/edit');
if(cachedResponse)
{
  $http({url: 'dc/'+did+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(sync){
        cachedResponse[1]=sync;
        httpCache.put('dc/'+did+'/edit',cachedResponse);
        $scope.data = sync;                  
  });  
}
  
}

// $scope.print = function()
// {    
//  $window.print();
// }
$scope.invoicechange = function(cur)
{
    if(cur=='All')
    {
        $scope.InvCur = angular.copy($scope.InvType);
    }
    else
    {
        $scope.InvCur=[];
        $scope.InvCur.push(cur);

    }
}

$scope.mailto =  function(ev){
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/mailto.html';
    $mdDialog.show(dialog);
}

$scope.sendmail =  function(){

    $mdDialog.hide();
    kendo.drawing.drawDOM($('.printpage'),{
    forcePageBreak: ".page-break"}).then(function(group){
    kendo.drawing.pdf.toDataURL(group, function(dataURL){
        $scope.emailform.Pdf=dataURL;
    $http({ url: 'sendinvoice', method: 'POST',data:$scope.emailform}).success(function(data){
        al('Invoice Sent Successfully');
    }).error(function(data,status){
            var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: 'Mail Configuration Error',
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    }); 

    });
    });
}

function al(text)
{
    $mdToast.show($mdToast.simple().textContent(text).position('bottom right').hideDelay(3000));
}

$scope.print = function(selector)
{
kendo.drawing.drawDOM($(selector),{
forcePageBreak: ".page-break"}).then(function(group){
kendo.drawing.pdf.toDataURL(group, function(dataURL){
$scope.url=dataURL;
});
});
}

})