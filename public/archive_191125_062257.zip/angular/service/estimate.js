app.config(['$routeProvider',function($routeProvider) {        
    $routeProvider
    .when('/create-estimate', {
        controller: 'EstcreateCtr',
        templateUrl: '/app/create-estimate.html',
        title: 'Estimate'
    })
    .when('/purchase-payments', {
        controller: 'PurPayCtr',
        templateUrl: '/app/purchase-payment.html',
        title: 'Purchase Payments'
    })
    .when('/expense', {
        controller: 'ExpenseCtr',
        templateUrl: '/app/expense.html',
        title: 'Expense'
    })
     .when('/estimate', {
        controller: 'EstCtr',
        templateUrl: '/app/estimate.html',
        title: 'Estimate'
    })
    .when('/estimate-edit/:id', {
        controller: 'EstcreateCtr',
        templateUrl: '/app/create-estimate.html',
        title: 'Edit Estimate'
    })
    .when('/estimate-print/:id', {
        controller: 'EstPrintCtr',
        templateUrl: '/app/est-print',
        title: 'Print'
    })
    .when('/purchase-reports', {
        controller: 'PurReportsCtr',
        templateUrl: '/app/purchase-report.html',
        title: 'Purchase Reports'
    });
}])
.controller('PurReportsCtr', function($q,$timeout,$window,$http,$scope,$cacheFactory,ngTableParams,$mdToast,$mdDialog,$location,$routeParams){
$scope.search={};
var dialog = {scope:$scope, preserveScope: true, controller: function($scope, $mdDialog){$scope.hide=function(){$mdDialog.hide(); if($scope.Type=='Edit'){$scope.form="";}$scope.formError='';};}, clickOutsideToHide:true};
$scope.FromDat=new Date();
$scope.ToDat=new Date();

$scope.searchform =  function(){

    $scope.search.FromDate = Math.round(new Date($scope.FromDat).getTime() / 1000);
    $scope.search.ToDate = Math.round(new Date($scope.ToDat).getTime() / 1000);
    $scope.search.SID=angular.copy($scope.form.Customer.SID);
    $http({ url: 'purchase-reports', method: 'GET',params:$scope.search}).success(function(data){
    $scope.data=data;
    });
 
}



$scope.mailto =  function(ev){
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/mailto.html';
    $mdDialog.show(dialog);
}

$scope.sendmail =  function(){

    $mdDialog.hide();
    kendo.drawing.drawDOM($('.printpage'),{paperSize:"a3"}).then(function(group){
    kendo.drawing.pdf.toDataURL(group, function(dataURL){
        $scope.emailform.Pdf=dataURL;
    $http({ url: 'sendinvoice', method: 'POST',data:$scope.emailform}).success(function(data){
        al('Report Sent Successfully');
    }).error(function(data,status){
            var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: 'Mail Configuration Error',
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    }); 

    });
    });
}

function al(text)
{
    $mdToast.show($mdToast.simple().textContent(text).position('bottom right').hideDelay(3000));
}
$scope.print = function(selector)
{
kendo.drawing.drawDOM($('.printpage'),{paperSize:"a3"}).then(function(group){
kendo.drawing.pdf.toDataURL(group, function(dataURL){
// window.open(dataURL,'_blank');
$scope.url = dataURL;
});
});
}


$http({url: 'suppliers/1', method: 'GET',cache:true, ignoreLoadingBar:true}).success(function(sync){
    $scope.Customers=sync;               
});
$scope.query = function(searchText) {

var deferred = $q.defer();

$timeout(function() {
    var states = getStates().filter(function(state) {
        return (state.Name.toUpperCase().indexOf(searchText.toUpperCase()) !== -1 || state.CName.toUpperCase().indexOf(searchText.toUpperCase()) !== -1);
    });
    deferred.resolve(states);
});

return deferred.promise;
   

};

function getStates() {
    return $scope.Customers;
    }

})
.controller('PurPayCtr', function($q,$filter,$window,$http,$scope,$cacheFactory,ngTableParams,$mdToast,$mdDialog,$rootScope,$route){
var httpCache = $cacheFactory.get('$http');
var path;

  $http({url: 'suppliers/1', method: 'GET',cache:true, ignoreLoadingBar:true}).success(function(sync){
        $scope.Customers=sync;               
  });

$scope.query = function(searchText) {
var deferred = $q.defer();
    var states = $scope.Customers.filter(function(state) {
        return (state.Name.toUpperCase().indexOf(searchText.toUpperCase()) !== -1 || state.CName.toUpperCase().indexOf(searchText.toUpperCase()) !== -1);
    });
    deferred.resolve(states);
return deferred.promise;
};


var dialog = {scope:$scope, preserveScope: true, controller: function($scope, $mdDialog){$scope.hide=function(){$mdDialog.hide(); if($scope.Type=='Edit'){$scope.custform="";}$scope.formError='';};}, clickOutsideToHide:true};
$scope.data=[];
$scope.tableSorting = new ngTableParams({
    page: 1,
    count: 10,
    sorting: {
        EXID: 'desc'
    },
    filter: {
        Type : 'Purchase'
    }
    }, {
    total: $scope.data.length, 
    getData: function($defer, params) {
        $rootScope.isLoading=true;
        path = 'expense?'+jQuery.param({
        "skip": (params.page() - 1) * params.count(),
        "take": params.count(),
        "filter":params.filter(),
        "orderBy": params.sorting()});

        $http({ cache: true, url: path, method: 'GET'})
        .success(function (result) {
            $scope.data = result.data;
            params.total(result.total);
            $defer.resolve(result.data);
            $rootScope.isLoading=false;
        }); 

        var cachedResponse = httpCache.get(path);
        if(cachedResponse)
        {
          $http({url: path, method: 'GET', ignoreLoadingBar:true}).success(function(sync){
                cachedResponse[1]=sync;
                httpCache.put(path,cachedResponse);
                $scope.data = sync.data;
                params.total(sync.total);
                $defer.resolve(sync.data); 
                $rootScope.isLoading=false;                  
          });  
        } 
    }
})

$scope.searchform =  function(){
 angular.extend($scope.tableSorting.filter(), $scope.search);   
}

$scope.makepay =  function(ev){
    $scope.Type='New';    
    $scope.form={Dat:new Date(),Type:'Purchase'};
    $mdDialog.show({      
      scope:$scope,  
      preserveScope: true,
      controller: DialogController,
      targetEvent:ev,
      templateUrl: 'register.html',
      clickOutsideToHide:true
    });
}

$scope.editpay =  function(data,index,ev){
    $scope.curid=index;
    $scope.form=data;
    $scope.form.Dat = new Date();
    $scope.form.Customer = $filter('filter')($scope.Customers, {SID:angular.copy(parseInt(data.SID))}, true)[0];
    $scope.Type='Edit';
    $mdDialog.show({      
      scope:$scope,  
      preserveScope: true,
      targetEvent: ev,
      controller: DialogController,
      templateUrl: 'register.html',
      clickOutsideToHide:true
    });
    
}


$scope.customerchange = function()
{
    if(angular.isDefined($scope.form.Customer)&&$scope.form.Customer!=null)
    {        
        $scope.form.SID=angular.copy($scope.form.Customer.SID);
    }

}

function DialogController($scope, $mdDialog) {
$scope.hide = function() {
  $mdDialog.hide();
};
}

$scope.submit =  function(){
    if($scope.Type=='New')
    {
        add();
    }
    else
    {
        update();
    }
}
function add()
{    
    if($scope.submitbutton==false)    
    {
        return;
    }
    $scope.submitbutton=false;

    var form=angular.copy($scope.form);
    form.Date= Math.round(new Date($scope.form.Dat).getTime() / 1000);
    $http({ url: 'expense', method: 'POST',data:form}).success(function(data){
        $mdDialog.hide();
        al('Payment created Successfully');
        $scope.data.push(data);
        $scope.submitbutton=true;
    }).error(function(data,status){
        $scope.formError=data;
        $scope.submitbutton=true;
    });
}

function update()
{    
    var form=angular.copy($scope.form);
    form.Date= Math.round(new Date($scope.form.Dat).getTime() / 1000);
    $http({ url: 'expense/'+$scope.form.EXID, method: 'PUT',data:form}).success(function(data){
        $mdDialog.hide();
        $scope.data[$scope.curid]=data;
        al('Payment Details Updated Successfully');
        $route.reload();
    }).error(function(data,status){
        $scope.formError=data;
    });
}

$scope.delete =  function(cid,index,ev){
    var confirm = $mdDialog.confirm({targetEvent:ev})
          .title('Are You sure to delete this Customer?')
          .ok('Yes')
          .cancel('No');

    $mdDialog.show(confirm).then(function() {
            $http({ url: 'expense/'+cid, method: 'DELETE'}).success(function(data){
                al('Deleted Successfully');
                $scope.data.splice(index,1);
                });
    }, function() {
        al('Delete Cancelled');
    });
}


function al(text)
{
    $mdToast.show($mdToast.simple().textContent(text).position('bottom right').hideDelay(3000));
}

})
.controller('ExpenseCtr', function($window,$http,$scope,$cacheFactory,ngTableParams,$mdToast,$mdDialog,$rootScope,$route){
var httpCache = $cacheFactory.get('$http');
$scope.ExpType = JSON.parse($rootScope.Authuser.ExpType);
var path;
var dialog = {scope:$scope, preserveScope: true, controller: function($scope, $mdDialog){$scope.hide=function(){$mdDialog.hide(); if($scope.Type=='Edit'){$scope.custform="";}$scope.formError='';};}, clickOutsideToHide:true};
$scope.data=[];
$scope.tableSorting = new ngTableParams({
    page: 1,
    count: 10,
    sorting: {
        EXID: 'desc'
    }
    }, {
    total: $scope.data.length, 
    getData: function($defer, params) {
        $rootScope.isLoading=true;
        path = 'expense?'+jQuery.param({
        "skip": (params.page() - 1) * params.count(),
        "take": params.count(),
        "filter":params.filter(),
        "orderBy": params.sorting()});

        $http({ cache: true, url: path, method: 'GET'})
        .success(function (result) {
            $scope.data = result.data;
            $scope.amount = result.amount;
            params.total(result.total);
            $defer.resolve(result.data);
            $rootScope.isLoading=false;
        }); 

        var cachedResponse = httpCache.get(path);
        if(cachedResponse)
        {
          $http({url: path, method: 'GET', ignoreLoadingBar:true}).success(function(sync){
                cachedResponse[1]=sync;
                httpCache.put(path,cachedResponse);
                $scope.data = sync.data;
                $scope.amount = sync.amount;

                params.total(sync.total);
                $defer.resolve(sync.data); 
                $rootScope.isLoading=false;                  
          });  
        } 
    }
})

$scope.search={};
$scope.searchform =  function(){
    $scope.search.FromDate = Math.round(new Date($scope.FromDat).getTime() / 1000);
    $scope.search.ToDate = Math.round(new Date($scope.ToDat).getTime() / 1000);

 angular.extend($scope.tableSorting.filter(), $scope.search);   
}

$scope.campcreate =  function(ev){
    $scope.Type='New';
    $scope.form={Dat:new Date()};
    $scope.formError='';
    dialog.targetEvent= ev;
    dialog.templateUrl= 'new-expense.html';
    $mdDialog.show(dialog);
}

$scope.campedit =  function(cid,index,ev){
    $scope.form="";    
    $scope.Type='Edit';
    $scope.formError='';
    $scope.curid=index;
    angular.forEach($scope.data, function(val){
        if(val.EXID==cid)
        { $scope.form=angular.copy(val); }
    });
    $scope.form.Dat = new Date();
    dialog.targetEvent= ev;
    dialog.templateUrl= 'new-expense.html';
    $mdDialog.show(dialog);
}

$scope.delete =  function(cid,index,ev){
    var confirm = $mdDialog.confirm({targetEvent:ev})
          .title('Are You sure to delete this Expense?')
          .ok('Yes')
          .cancel('No');

    $mdDialog.show(confirm).then(function() {
            $http({ url: 'expense/'+cid, method: 'DELETE'}).success(function(data){
                al('Deleted Successfully');
                $scope.data.splice(index,1);
                }).error(function(data,status){
                    al('Cant Delate');
                });
    }, function() {
        al('Delete Cancelled');
    });
}

$scope.createExpense =  function(){

    $scope.form.Date= Math.round(new Date($scope.form.Dat).getTime() / 1000);
    if($scope.Type=='New')
    {
        add();
    }
    else
    {
        update();
    }
}
function add()
{    
    var custform=angular.copy($scope.form);
    $http({ url: 'expense', method: 'POST',data:custform}).success(function(data){
        al('Expense created Successfully');
    $mdDialog.hide();
    $scope.form='';
    $scope.data.push(data);
    }).error(function(data,status){
        $scope.formError=data;
    });
}

function update()
{    
    var custform=angular.copy($scope.form);
    $http({ url: 'expense/'+$scope.form.EXID, method: 'PUT',data:custform}).success(function(data){
        al('Expense Details Updated Successfully');
    $mdDialog.hide();
    $scope.form='';
    $scope.data[$scope.curid]=data;
    }).error(function(data,status){
        $scope.formError=data;
    });
}

function al(text)
{
    $mdToast.show($mdToast.simple().textContent(text).position('bottom right').hideDelay(3000));
}

})
.controller('EstcreateCtr', function($rootScope,$mdDialog, $filter,$q,$timeout, $http,$scope,$cacheFactory,ngTableParams,$mdToast,$mdDialog,$location,$routeParams){

var iid=$routeParams.id;
var rid=$routeParams.rid;
var dc=$routeParams.dc;
var httpCache = $cacheFactory.get('$http');    
$scope.form2={};
$scope.multiple=false;

  $http({url: 'customers/1', method: 'GET',cache:true, ignoreLoadingBar:true}).success(function(sync){
        $scope.Customers=sync;               
  });
    $http({url: 'items', method: 'GET',cache:true, ignoreLoadingBar:true}).success(function(items){
        $scope.Items=items;               
  });

if(iid)
{
$scope.Type="Edit";
$http({url: 'estimate/'+iid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(data){
$scope.details=data.details;

$scope.form=data;
$scope.form.Dat=new Date(data.Date*1000);
$scope.form.Du=new Date(data.Due*1000);
$scope.form.Customer = $filter('filter')($scope.Customers, {CID:angular.copy(parseInt(data.CID))}, true)[0];
// $scope.form.Customer=data.CName;
if(data.details[0].RIGST==0)
{
    $scope.form.GST=data.details[0].RCGST*2;
}
else
{
    $scope.form.GST=data.details[0].RIGST;
}
});

$scope.data=print.data;
var cachedResponse = httpCache.get('invoice/'+iid+'/edit');
if(cachedResponse)
{
  $http({url: 'invoice/'+iid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(sync){
        cachedResponse[1]=sync;
        httpCache.put('invoice/'+iid+'/edit',cachedResponse);
        
        $scope.details=sync.details;
        $scope.form=sync;
        $scope.form.Dat=new Date(sync.Date*1000); 
        $scope.form.Du=new Date(sync.Due*1000); 
        $scope.form.Customer=data.CName;    
                      

  });  
}

}
else
{
$scope.Type="Create";    
$scope.details=[];
$scope.form={Dat: new Date(),Du: new Date()};
}


if(dc)
{

    $scope.fromdc=true;
    var httpCache = $cacheFactory.get('$http');    
    var cachedResponse = httpCache.get('dcconvert');
    if(cachedResponse)
    {    
        $http({url: 'dcdetails?ids='+cachedResponse.DCID, method: 'GET', ignoreLoadingBar:true}).success(function(details){        
            angular.forEach(details, function(val){
                var dcitem = $filter('filter')($scope.Items, {ITID:angular.copy(parseInt(val.ITID))}, true)[0];
                val.Item=angular.copy(dcitem);
                val.ITID=angular.copy(dcitem.ITID);
                val.IName=angular.copy(dcitem.IName);
                val.Rate=angular.copy(dcitem.SRate);
                val.Amount=Math.round(parseFloat(val.Rate)*parseFloat(val.Qty)*100)/100;
                $scope.details.push(val);
            }); 
            $scope.form.Customer = $filter('filter')($scope.Customers, {CID:angular.copy(parseInt(cachedResponse.CID))}, true)[0];
        });
    }
    else
    {
        $location.path('/dc');        
    }
    $scope.form.Dat=new Date(); 
    $scope.form.Du=new Date(); 


}

$scope.query = function(searchText) {
var deferred = $q.defer();
$timeout(function() {
    var states = getStates().filter(function(state) {
        return (state.Name.toUpperCase().indexOf(searchText.toUpperCase()) !== -1 || state.CName.toUpperCase().indexOf(searchText.toUpperCase()) !== -1);
    });
    deferred.resolve(states);
}, 0);
return deferred.promise;
};

function getStates() {
    return $scope.Customers;
    }




$scope.fill =  function(){

        angular.forEach($scope.dc, function(val){
            if(val.DcNo==$scope.form2.Dc)
            {
                var curdata=angular.copy(val);
                $scope.form2.Date=$filter('date')(curdata.Date*1000, "dd-MM-yyyy");
                $scope.form2.Dat=curdata.Date;
                $scope.form2.Des=curdata.Description;
                $scope.form2.Qty=curdata.TotMeters;
            }
        });
}

$scope.create =  function(){
    
    $scope.form.Date = Math.round(new Date($scope.form.Dat).getTime() / 1000);

    var date = new Date($scope.form.Dat);
    date.setDate(date.getDate() + $rootScope.Authuser.Due*1);
    $scope.form.Due = Math.round(date.getTime() / 1000);

// console.log($scope.Type);
// return;
    if($scope.Type=='Create')
    {
        if(rid)
        {
           $scope.form.RID=rid; 
        }
        newin();
    }
    else
    {
        updatein();
    }

     
}

function newin()
{
    if($scope.details.length>0&&$scope.form.Total)
    {

    if($scope.submitbutton==false)    
    {
        return;
    }
    $scope.submitbutton=false;
        $mdDialog.hide();

    $http({ url: 'estimate', method: 'POST',data:{invoice:$scope.form,details:$scope.details}}).success(function(data){
        al('Estimate created Successfully');
    $location.path('/estimate');

    }).error(function(data,status){
        $scope.formError=data;
        $scope.submitbutton=true;
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: data,
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    }); 
    }
    else
    {
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: 'Add atleast one record',
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    }
}

function updatein()
{
    if($scope.details.length>0)
    {
        $mdDialog.hide();
        
    $http({ url: 'estimate/'+$scope.form.EID, method: 'PUT',data:{invoice:$scope.form,details:$scope.details}}).success(function(data){
        al('Estimate Updated Successfully');
    $location.path('/estimate');

    }).error(function(data,status){
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: data,
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    });
    }
    else
    {
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: 'Add atleast one record',
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    }
}

$scope.cancel =  function(status){

   $http({ url: 'estimate-st', method: 'POST',data:{EID:$scope.form.EID,Status:status}}).success(function(data){
        $scope.form.Status=data.Status;
        al('Status changed Successfully');
    }).error(function(data,status){
        var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: data,
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    });
}

$scope.delete =  function(index){
    $scope.details.splice(index,1);
    calctotal();
}

$scope.edit =  function(index){
    $scope.form2=angular.copy($scope.details[index]);
    $scope.form2.Item = $filter('filter')($scope.Items, {ITID:angular.copy(parseInt($scope.form2.ITID))}, true)[0];    
    $scope.curedit=index;
}

$scope.save =  function(index){

    $scope.details[$scope.curedit]=angular.copy($scope.form2);
    $scope.form2="";
    $scope.curedit=undefined;
    calctotal();
}


function al(text)
{
    $mdToast.show($mdToast.simple().textContent(text).position('bottom right').hideDelay(3000));
}

var dialog = {scope:$scope, preserveScope: true, controller: function($scope, $mdDialog){$scope.hide=function(){$mdDialog.hide(); if($scope.Type=='Edit'){$scope.custform="";}$scope.formError='';};}, clickOutsideToHide:true};


$scope.invoicedetails =  function(ev){
    $scope.formError='';
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/invoicedetails.html';
    $mdDialog.show(dialog);
}

$scope.createNewCustomer =  function(ev){
    $scope.Type='New';
    $scope.formError='';
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/new-customer.html';
    $mdDialog.show(dialog);
}

$scope.createCustomer = function()
{    
    var custform=angular.copy($scope.custform);
    $http({ url: 'customers', method: 'POST',data:custform}).success(function(data){
        al('Customer created Successfully');
    $mdDialog.hide();
    $scope.custform='';
    $scope.Customers.push(data);
    var cachedResponse = httpCache.get('customers/1');
    cachedResponse[1]=$scope.data;
    httpCache.put('customers/1',cachedResponse);
    $scope.form.Customer=data;
    }).error(function(data,status){
        $scope.formError=data;
    });
}

$scope.itemquery = function(itemText) {
    console.log(itemText);
var deferred = $q.defer();
// var states = getitem().filter(function(state) {
var states = $scope.Items.filter(function(state) {
    return (state.IName.toUpperCase().indexOf(itemText.toUpperCase()) !== -1);
});
deferred.resolve(states);
return deferred.promise;
};

// $scope.itemquery = function(itemText) {
// var deferred = $q.defer();
// var states = getitem().filter(function(state) {
//     return (state.IName.toUpperCase().indexOf(itemText.toUpperCase()) !== -1);
// });
// deferred.resolve(states);
// return deferred.promise;
// };

function getitem()
{
    // return $scope.Items;
    if($scope.form.GST==undefined||$scope.form.GST=='')
    {
        return [];
    }
    return $filter('filter')($scope.Items, {GST:angular.copy(parseInt($scope.form.GST))}, true);

}

$scope.createNewItem =  function(ev){
    $scope.Type='New';
    $scope.formError='';
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/new-item.html';
    $mdDialog.show(dialog);
}

$scope.customerchange = function()
{
    if(angular.isDefined($scope.form.Customer)&&$scope.form.Customer!=null)
    {        
        // $scope.details=[];
        $scope.form.CID=angular.copy($scope.form.Customer.CID);
        $scope.form.State=angular.copy($scope.form.Customer.State);
        $scope.calcdetails();
        $("#vno" ).focus();
    }

}

$scope.inamechange = function()
{
    if(!$scope.form2.IName)
    {        
        $scope.form2.Item = undefined;
    }
}

$scope.itemchange = function()
{
    if(angular.isDefined($scope.form2.Item)&&$scope.form2.Item!=null)
    {        
        $scope.form2.ITID=angular.copy($scope.form2.Item.ITID);
        $scope.form2.IName=angular.copy($scope.form2.Item.IName);
        $scope.form2.HSN=angular.copy($scope.form2.Item.HSN);
        $scope.form2.Rate=angular.copy($scope.form2.Item.SRate);
        $scope.form2.GST=angular.copy($scope.form2.Item.GST);
        console.log($scope.form2.Item);
        $scope.calc();
     $( "#qty" ).focus();

    }
}
$scope.gstchange = function()
{
    $scope.details=[];
    calctotal();
}


$scope.createItem =  function()
{    
    var form=angular.copy($scope.form);
    $http({ url: 'items', method: 'POST',data:form}).success(function(data){
        al('Item created Successfully');
    $mdDialog.hide();
    $scope.form='';
    $scope.Items.push(data);

    var cachedResponse = httpCache.get('items');
    cachedResponse[1]=$scope.Items;
    httpCache.put('items',cachedResponse);
    $scope.form2.Item=data;
    }).error(function(data,status){
        $scope.formError=data;
    });
}


$scope.calc =  function(){
    if($scope.form.Customer==undefined||$scope.form.Customer==null)
    {
        var confirm = $mdDialog.alert({
            title: 'Warning',
            textContent: 'Select Customer',
            ok: 'Close'
          });
        $mdDialog.show(confirm);
        $scope.form2.Rate=0;
        $scope.form2.Qty=0;
        $scope.form2.Taxable=0;
        return;
    }
    $scope.form2.Amount=Math.round(parseFloat($scope.form2.Rate)*parseFloat($scope.form2.Qty)*100)/100;
    if($scope.form.State==32)
    {
        $scope.form2.RCGST=angular.copy($scope.form2.GST/2);
        $scope.form2.RSGST=angular.copy($scope.form2.GST/2);
        $scope.form2.RIGST=0;
        var gst = angular.copy(($scope.form2.Amount*$scope.form2.RCGST)/100);
        $scope.form2.CGST=gst;
        $scope.form2.SGST=gst;
        $scope.form2.IGST=0;
    }
    else
    {
        $scope.form2.RCGST=0;
        $scope.form2.RSGST=0;
        $scope.form2.RIGST=angular.copy($scope.form2.GST);
        var gst = angular.copy(($scope.form2.Amount*$scope.form2.RIGST)/100);
        $scope.form2.CGST=0;
        $scope.form2.SGST=0;
        $scope.form2.IGST=gst;
    }
     $scope.form2.Total=$scope.form2.Amount+$scope.form2.CGST+$scope.form2.SGST+$scope.form2.IGST;   

}

$scope.calcdetails =  function(){
    console.log($scope.form.Customer.CID);

    if($scope.form.Customer==undefined||$scope.form.Customer==null)
    {
        return;
    }    

     angular.forEach($scope.details, function(val,key){
        // if(val.GST==undefined)
        // {
        //     calctotal();
        //     return;
        // }
            if($scope.form.State==32)
            {
                val.RCGST=angular.copy(val.GST/2);
                val.RSGST=angular.copy(val.GST/2);
                val.RIGST=0;
                var gst = angular.copy((val.Amount*val.RCGST)/100);
                val.CGST=gst;
                val.SGST=gst;
                val.IGST=0;
            }
            else
            {
                val.RCGST=0;
                val.RSGST=0;
                val.RIGST=angular.copy(val.GST);
                var gst = angular.copy((val.Amount*val.RIGST)/100);
                val.CGST=0;
                val.SGST=0;
                val.IGST=gst;
            }
            val.Total=val.Amount*1+val.CGST+val.SGST+val.IGST;
            $scope.details[key]=val;
    });
     calctotal();
   

}


$scope.add =  function(){

    if ($scope.curedit!=undefined) {
        $scope.save();
        return;
    }
    console.log($scope.curedit);
    if($scope.form2.Amount&&$scope.form2.Qty>0)
    {
       $scope.details.push(angular.copy($scope.form2));
       $scope.form2='';
       calctotal(); 
    }    
}

function calctotal()
{   
    var qty=0;
    var amount=0;
    var cgst=0;
    var sgst=0;
    var igst=0;
    var round=0;

    angular.forEach($scope.details, function(val){
        qty=qty+parseInt(val.Qty);
        amount=amount+parseFloat(val.Amount);
        cgst=cgst+parseFloat(val.CGST);
        sgst=sgst+parseFloat(val.SGST);
        igst=igst+parseFloat(val.IGST);
    });
    var total = Math.round(amount+cgst+sgst+igst);
    round=Math.round((total-(amount+cgst+sgst+igst))*100)/100;

    $scope.form.Qty=qty
    $scope.form.Amount=amount;
    $scope.form.CGST=cgst;
    $scope.form.SGST=sgst;
    $scope.form.IGST=igst;
    $scope.form.Total=total;
    $scope.form.Round=round;
    $scope.form.Balance=total;
}

$scope.todelete =  function(iid){
   var confirm = $mdDialog.confirm()
          .title('Are You sure to delete this Estimate?')
          .ok('Yes Delete it!')
          .cancel('Cancel');

    $mdDialog.show(confirm).then(function() {
            $http({ url: 'estimate/'+iid, method: 'DELETE'}).success(function(data){
                al('Deleted Successfully');
                $location.path('/estimate');
                }).error(function(data,status){
                    al('This Estimate in use. Cant Delate');
                });
    }, function() {
        al('Delete Cancelled');
    });
}


})
.controller('EstCtr', function($http,$scope,$cacheFactory,ngTableParams,$mdToast,$mdDialog,$rootScope,$location){

var path;
var httpCache = $cacheFactory.get('$http');

    $scope.mainGridOptions = {
                dataSource: {
                    transport: {
                        read : function (options) {

                            path = '/estimate?'+jQuery.param(options.data);
                            $http({ url: path, method: 'GET', cache: true}).success(function(data){
                                options.success(data);
                            });
                            var cachedResponse = httpCache.get(path);
                            if(cachedResponse)
                            {
                              $http({url: path, method: 'GET'}).success(function(sync){
                                    options.success(sync);
                                    cachedResponse[1]=sync;
                                    httpCache.put(path,cachedResponse);                 
                              });  
                            }

                            }
                    },
                    schema: {
                        data: "data", 
                        total: "total"
                    },
                    sort: {
                        field: "EsNo",
                        dir: "desc"
                    },
                    height: 550,
                    groupable: true,
                    pageSize: 5,
                    serverFiltering: true,
                    serverPaging: true,
                    serverSorting: true,
                    filter: { Status:"Payable" },                    
                },
                sortable: true,                
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5,
                    pageSizes: [5,10,20,50,100]
                },
                columns: [{
                    field: "EsNo",
                    title: "Estimate No",
                    width: "120px"
                    },{
                    template: '{{#: Date #*1000|date:"dd-MM-yyyy"}}',
                    field: "Date",
                    title: "Date",
                    width: "120px"
                    },{
                    template: '<a href="" > #: CName # - #: Mobile1 #</a>',
                    field: "CName",
                    title: "Company"
                    },{
                    template: '{{dataItem.Total | currency : "&\\#8377; " : 2}}',
                    field: "Total",
                    width: "120px"
                    },{
                    template: '{{dataItem.Balance | currency : "&\\#8377; " : 2}}',
                    field: "Balance",
                    width: "120px"
                    },{
                    template:'<span class="label" ng-class="{Payable:\'label-success\', Closed:\'label-success\',Cancelled:\'label-warning\',Regen:\'label-warning\'}[dataItem.Status]">#: Status #</span>',
                    field: "Status",
                    width: "120px"
                    },{
                    template:'<ul class="icons-list"><li class="dropdown"><a href="\\#/estimate-edit/{{dataItem.EID}}" class="dropdown-toggle md-primary" data-toggle="dropdown"><i class="glyphicon glyphicon-edit"></i></a></li><li class="dropdown"><a href="\\#/estimate-print/{{dataItem.EID}}" class="dropdown-toggle"  md-colors="{color: \'pink\'}" data-toggle="dropdown"><i class="glyphicon glyphicon-print"></i></a></li></ul>',
                    title: "Actions",
                    width: "90px"
                }]
            };
            
$scope.search={};

$scope.searchform =  function(){

    var grid = $("#grid").data("kendoGrid");
    $scope.search.FromDate = Math.round(new Date($scope.FromDat).getTime() / 1000);
    $scope.search.ToDate = Math.round(new Date($scope.ToDat).getTime() / 1000);
    grid.dataSource.filter($scope.search);
 
}

$scope.reset =  function(){
    $scope.ToDat=null;
    $scope.FromDat=null;
    $scope.search={};
    var grid = $("#grid").data("kendoGrid");
    grid.dataSource.filter($scope.search);
 
}

})
.controller('EstPrintCtr', function($mdToast,$timeout,$filter,$window,$http,$scope,$cacheFactory,ngTableParams,$mdToast,$mdDialog,$location,$routeParams,$rootScope){

var iid=$routeParams.id;
var sid=$routeParams.sid;
var did=$routeParams.did;
$scope.InvType = JSON.parse($rootScope.Authuser.InvType);
$scope.InvCur = angular.copy($scope.InvType);
var dialog = {scope:$scope, preserveScope: true, controller: function($scope, $mdDialog){$scope.hide=function(){$mdDialog.hide(); if($scope.Type=='Edit'){$scope.form="";}$scope.formError='';};}, clickOutsideToHide:true};


if(iid)
{
$http({url: 'estimate/'+iid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(data){
$scope.data = data; 

$timeout(function(){

$scope.tbody = angular.element("#tbody")[0].offsetHeight;
var tbody=angular.copy($scope.tbody);
if(tbody<1070)
{
    $scope.myheight={'height':(1070-tbody)+'px'};
}

},500);



});


$scope.data=print.data;
var httpCache = $cacheFactory.get('$http');    
var cachedResponse = httpCache.get('invoice/'+iid+'/edit');
if(cachedResponse)
{
  $http({url: 'invoice/'+iid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(sync){
        cachedResponse[1]=sync;
        httpCache.put('invoice/'+iid+'/edit',cachedResponse);
        $scope.data = sync;  

        $timeout(function(){

        $scope.tbody = angular.element("#tbody")[0].offsetHeight;
        var tbody=angular.copy($scope.tbody);
        console.log(tbody);
        if(tbody<1000)
        {
            $scope.myheight={'height':(1000-tbody)+'px'};
        }

        },500);

  });  
}
  
}


else if(sid)
{

$http({url: 'packing/'+sid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(data){
$scope.data = data;                  
});

$scope.data=print.data;
var httpCache = $cacheFactory.get('$http');    
var cachedResponse = httpCache.get('packing/'+sid+'/edit');
if(cachedResponse)
{
  $http({url: 'packing/'+sid+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(sync){
        cachedResponse[1]=sync;
        httpCache.put('packing/'+sid+'/edit',cachedResponse);
        $scope.data = sync;                  
  });  
}
  
}

else if(did)
{

$http({url: 'dc/'+did+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(data){
$scope.data = data;                  
});

$scope.data=print.data;
var httpCache = $cacheFactory.get('$http');    
var cachedResponse = httpCache.get('dc/'+did+'/edit');
if(cachedResponse)
{
  $http({url: 'dc/'+did+'/edit', method: 'GET', ignoreLoadingBar:true}).success(function(sync){
        cachedResponse[1]=sync;
        httpCache.put('dc/'+did+'/edit',cachedResponse);
        $scope.data = sync;                  
  });  
}
  
}

// $scope.print = function()
// {    
//  $window.print();
// }
$scope.invoicechange = function(cur)
{
    if(cur=='All')
    {
        $scope.InvCur = angular.copy($scope.InvType);
    }
    else
    {
        $scope.InvCur=[];
        $scope.InvCur.push(cur);

    }
}

$scope.mailto =  function(ev){
    dialog.targetEvent= ev;
    dialog.templateUrl= '/app/mailto.html';
    $mdDialog.show(dialog);
}

$scope.sendmail =  function(){

    $mdDialog.hide();
    kendo.drawing.drawDOM($('.printpage'),{
    forcePageBreak: ".page-break"}).then(function(group){
    kendo.drawing.pdf.toDataURL(group, function(dataURL){
        $scope.emailform.Pdf=dataURL;
    $http({ url: 'sendinvoice', method: 'POST',data:$scope.emailform}).success(function(data){
        al('Estimate Sent Successfully');
    }).error(function(data,status){
            var confirm = $mdDialog.alert({
                title: 'Warning',
                textContent: 'Mail Configuration Error',
                ok: 'Close'
              });
        $mdDialog.show(confirm);
    }); 

    });
    });
}

function al(text)
{
    $mdToast.show($mdToast.simple().textContent(text).position('bottom right').hideDelay(3000));
}

$scope.print = function(selector)
{

    console.log(selector);
kendo.drawing.drawDOM($(selector),{
forcePageBreak: ".page-break"}).then(function(group){
// kendo.drawing.pdf.saveAs(group, "Estimate.pdf");
kendo.drawing.pdf.toDataURL(group, function(dataURL){
$scope.url=dataURL;
});
});
}

})